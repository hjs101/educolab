-- MySQL dump 10.13  Distrib 8.0.28, for Win64 (x86_64)
--
-- Host: 3.36.69.192    Database: educolab
-- ------------------------------------------------------
-- Server version	8.0.30-0ubuntu0.20.04.2

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `notice_notice`
--

DROP TABLE IF EXISTS `notice_notice`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `notice_notice` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `classification` varchar(45) NOT NULL,
  `title` varchar(45) NOT NULL,
  `created_at` datetime(6) NOT NULL,
  `updated_at` datetime(6) NOT NULL,
  `content` longtext NOT NULL,
  `views` int NOT NULL,
  `school_id` varchar(7) NOT NULL,
  `teacher_id` varchar(20) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `notice_notice_school_id_0e5f7d23_fk_accounts_schoolinfo_code` (`school_id`),
  KEY `notice_notice_teacher_id_075a0a6d_fk_accounts_userinfo_username` (`teacher_id`),
  CONSTRAINT `notice_notice_school_id_0e5f7d23_fk_accounts_schoolinfo_code` FOREIGN KEY (`school_id`) REFERENCES `accounts_schoolinfo` (`code`),
  CONSTRAINT `notice_notice_teacher_id_075a0a6d_fk_accounts_userinfo_username` FOREIGN KEY (`teacher_id`) REFERENCES `accounts_userinfo` (`username`)
) ENGINE=InnoDB AUTO_INCREMENT=71 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `notice_notice`
--

LOCK TABLES `notice_notice` WRITE;
/*!40000 ALTER TABLE `notice_notice` DISABLE KEYS */;
INSERT INTO `notice_notice` VALUES (7,'공지','이번주 수업 참여도 우수자 목록','2022-08-08 01:29:27.522351','2022-08-19 00:59:56.032494','8월 2주차 수업 참여도 우수자 목록입니다.',185,'7003850','teacher01'),(8,'공지','쓰레기를 분리수거 해주세요','2022-08-08 01:31:50.687604','2022-08-17 06:27:32.217016','패트병은 라벨을 제거하여 주시고, 플라스틱, 캔은 찌그러뜨려 부피를 줄여서 버려주시기 바랍니다.',15,'7003850','teacher01'),(9,'행사','체육대회 안내','2022-08-08 01:34:01.685710','2022-08-17 06:06:29.093263','학교 체육대회가 8월 10일 진행됩니다.',12,'7003850','teacher01'),(10,'공지','학부모 참관 수업 안내','2022-08-08 01:35:27.415545','2022-08-17 13:51:39.962689','8월 11일 학부모 참관 수업이 예정되어있습니다. 1',35,'7003850','teacher01'),(11,'공지','학교 축제 당부사항','2022-08-08 01:37:01.837468','2022-08-17 13:51:10.647581','8월 19일 진행되는 학교 축제에서의 당부사항입니다.',11,'7003850','teacher01'),(12,'변경','시간표 변경 안내','2022-08-08 01:38:44.157965','2022-08-19 00:31:10.660982','오늘 수학 교과 OOO 선생님이 출장인 관계로 수학 수준별 수업(상)은 자습으로 대체됩니다.',8,'7003850','teacher01'),(13,'공지','교내봉사 대상자','2022-08-08 01:40:29.759066','2022-08-17 14:53:39.014037','8월 2주차 교내봉사 대상자입니다.',22,'7003850','teacher01'),(14,'공지','특별활동 선택 마감 기한 안내','2022-08-08 01:41:39.926870','2022-08-17 13:46:19.380487','특별활동 선택 마감 기한이 8월 31일 까지입니다. 기한 내에 선택하여 담임선생님께 알려주시길 바랍니다.',18,'7003850','teacher01'),(17,'공지','가정통신','2022-08-08 05:34:29.468493','2022-08-19 01:01:51.418612','가정통신문입니다.',58,'7003850','teacher01'),(51,'공지','급식시간에 줄을 잘 지킵시다.','2022-08-17 06:09:06.639017','2022-08-18 06:37:23.990355','새치기는 하지마세요.',12,'7003850','teacher01'),(52,'공지','중간고사 일정 안내','2022-08-17 06:12:31.978296','2022-08-19 00:59:24.196626','2학기 중간고사는 2022-08-30~2022-09-02 입니다.',18,'7003850','teacher01'),(53,'공지','교내 흡연자 처벌안내','2022-08-17 06:13:32.858596','2022-08-18 23:41:07.358873','앞으로 교내에서 흡연하다 적발 시 벌점을 3점 부여하도록 하겠습니다',7,'7003850','teacher01'),(54,'행사','교내 논술대회 일정 안내','2022-08-17 06:15:45.510467','2022-08-18 23:41:05.215693','2022-09-12(월) 방과후 교내 논술대회가 있을 예정입니다.<div>자세한 내용은 추후 공지사항으로 발송하겠습니다.</div>',10,'7003850','teacher01'),(55,'공지','9월 급식 일정 안내','2022-08-17 06:18:46.459417','2022-08-19 00:59:21.841082','9월 급식 일정입니다.',33,'7003850','teacher01'),(56,'공지','시험 기간 시험 지원 학부모님 안내','2022-08-17 06:20:44.496670','2022-08-19 00:59:02.498655','시험기간 시험을 위해 지원해주신 학부모님들께 문자메세지 드렸습니다.',22,'7003850','teacher01'),(58,'변경','태풍으로 인한 수학여행 취소','2022-08-17 06:51:18.893681','2022-08-19 00:58:52.317641','이번주 수요일부터 상륙하는 태풍 볼라벤으로 인해 불가피하게 수학여행은 취소하게 되었습니다.',123,'7003850','teacher01');
/*!40000 ALTER TABLE `notice_notice` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-08-19 10:03:14
