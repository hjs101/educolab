-- MySQL dump 10.13  Distrib 8.0.28, for Win64 (x86_64)
--
-- Host: 3.36.69.192    Database: educolab
-- ------------------------------------------------------
-- Server version	8.0.30-0ubuntu0.20.04.2

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `accounts_pointlog`
--

DROP TABLE IF EXISTS `accounts_pointlog`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `accounts_pointlog` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `content` varchar(45) NOT NULL,
  `point` int NOT NULL,
  `student_id` varchar(20) DEFAULT NULL,
  `created_at` date NOT NULL,
  `teacher_id` varchar(20) DEFAULT NULL,
  `acc_minus` int DEFAULT NULL,
  `acc_point` int DEFAULT NULL,
  `school_id` varchar(7) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `accounts_pointlog_student_id_a60a2aed_fk_accounts_` (`student_id`),
  KEY `accounts_pointlog_teacher_id_ef3ff890_fk_accounts_` (`teacher_id`),
  KEY `accounts_pointlog_school_id_96f65df0_fk_accounts_schoolinfo_code` (`school_id`),
  CONSTRAINT `accounts_pointlog_school_id_96f65df0_fk_accounts_schoolinfo_code` FOREIGN KEY (`school_id`) REFERENCES `accounts_schoolinfo` (`code`),
  CONSTRAINT `accounts_pointlog_student_id_a60a2aed_fk_accounts_` FOREIGN KEY (`student_id`) REFERENCES `accounts_userinfo` (`username`),
  CONSTRAINT `accounts_pointlog_teacher_id_ef3ff890_fk_accounts_` FOREIGN KEY (`teacher_id`) REFERENCES `accounts_userinfo` (`username`)
) ENGINE=InnoDB AUTO_INCREMENT=78 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `accounts_pointlog`
--

LOCK TABLES `accounts_pointlog` WRITE;
/*!40000 ALTER TABLE `accounts_pointlog` DISABLE KEYS */;
INSERT INTO `accounts_pointlog` VALUES (1,'수업참여',10,'stu01','2022-08-05','teacher01',NULL,NULL,NULL),(2,'수업참여',10,'stu02','2022-08-05','teacher01',NULL,NULL,NULL),(3,'과제 점수',3,'stu01','2022-08-09','teacher01',NULL,NULL,NULL),(4,'과제 점수',0,'stu01','2022-08-10','teacher01',NULL,NULL,NULL),(5,'과제 점수',0,'stu01','2022-08-10','teacher01',NULL,NULL,NULL),(6,'과제 점수',-1,'stu02','2022-08-10','teacher01',NULL,NULL,NULL),(7,'과제 점수',-1,'stu03','2022-08-10','teacher01',NULL,NULL,NULL),(8,'과제 점수',0,'stu01','2022-08-10','teacher01',NULL,NULL,NULL),(9,'과제 점수',1,'stu01','2022-08-10','teacher01',NULL,NULL,NULL),(10,'과제 점수',2,'stu01','2022-08-10','teacher01',NULL,NULL,NULL),(11,'과제 점수',3,'stu01','2022-08-10','teacher01',NULL,NULL,NULL),(12,'과제 점수',3,'stu01','2022-08-10','teacher01',NULL,NULL,NULL),(13,'과제 점수',3,'stu01','2022-08-10','teacher01',NULL,NULL,NULL),(14,'과제 점수',0,'stu01','2022-08-10','teacher01',NULL,NULL,NULL),(15,'과제 점수',0,'stu01','2022-08-11','teacher01',NULL,NULL,NULL),(16,'과제 점수',0,'stu01','2022-08-11','teacher01',NULL,NULL,NULL),(17,'과제 점수',0,'stu02','2022-08-11','teacher01',NULL,NULL,NULL),(18,'과제 점수',1,'stu01','2022-08-11','teacher01',NULL,NULL,NULL),(19,'불성실한 청소',-1,'stu05','2022-08-12','teacher01',NULL,NULL,NULL),(20,'수업 시간 참여율 우수',5,'stu03','2022-08-12','teacher01',NULL,NULL,NULL),(21,'수업 시간 발표',2,'stu01','2022-08-12','teacher01',NULL,NULL,NULL),(22,'수업 시간 참여율 우수',3,'stu01','2022-08-12','teacher01',NULL,NULL,NULL),(23,'수업시간 참여율 우수',2,'stu08','2022-08-12','teacher01',NULL,NULL,NULL),(24,'상점 부여',5,'stu01','2022-08-14','teacher01',0,49,NULL),(25,'상점 부여',5,'stu01','2022-08-14','teacher01',0,54,NULL),(26,'벌점 부여',-5,'stu01','2022-08-14','teacher01',5,54,NULL),(27,'벌점 부여',-5,'stu01','2022-08-14','teacher01',0,54,NULL),(28,'벌점 부여',-5,'stu01','2022-08-14','teacher01',-5,54,NULL),(29,'과제 점수',-1,'stu03','2022-08-15','teacher01',NULL,NULL,NULL),(30,'과제 점수',-1,'stu01','2022-08-15','teacher01',NULL,NULL,NULL),(31,'과제 점수',-1,'stu02','2022-08-15','teacher01',NULL,NULL,NULL),(32,'과제 점수',-1,'stu03','2022-08-15','teacher01',NULL,NULL,NULL),(33,'과제 점수',-1,'stu02','2022-08-15','teacher01',NULL,NULL,NULL),(34,'과제 점수',5,'stu01','2022-08-15','teacher01',NULL,NULL,NULL),(35,'과제 점수',5,'stu01','2022-08-15','teacher01',NULL,NULL,NULL),(36,'점수부여 테스트',300,'stu01','2022-08-15','teacher01',-6,634,NULL),(37,'과제 점수',3,'stu01','2022-08-16','teacher01',0,0,NULL),(38,'과제 점수',3,'stu01','2022-08-16','teacher01',0,0,NULL),(39,'과제 점수',4,'stu01','2022-08-16','teacher01',0,0,NULL),(40,'학업우수',3,'stu01','2022-08-16','teacher01',-6,217,NULL),(41,'과제 점수',3,'stu01','2022-08-17','teacher01',0,0,NULL),(42,'상점 부여',3,'stu01','2022-08-17','teacher01',-6,23,NULL),(43,'과제 점수',3,'stu01','2022-08-17','teacher01',0,0,NULL),(44,'과제 점수',3,'stu01','2022-08-17','teacher01',-6,29,NULL),(45,'과제 점수',3,'stu01','2022-08-17','teacher01',-6,32,NULL),(46,'착한 행동',10,'stu01','2022-08-18','teacher01',-6,42,'7003850'),(47,'착한 행동',3,'stu02','2022-08-18','teacher01',-3,13,'7003850'),(48,'과제 점수',5,'stu01','2022-08-18','teacher01',-6,47,'7003850'),(49,'과제 점수',5,'stu02','2022-08-18','teacher01',-3,18,'7003850'),(50,'학업우수',10,'stu03','2022-08-18','teacher01',-3,15,'7003850'),(51,'태도우수',10,'stu03','2022-08-18','teacher01',-3,25,'7003850'),(52,'봉사활동',10,'stu03','2022-08-18','teacher01',-3,35,'7003850'),(53,'태도우수',10,'stu02','2022-08-18','teacher01',-3,28,'7003850'),(54,'봉사활동',10,'stu02','2022-08-18','teacher01',-3,38,'7003850'),(55,'과제 점수',3,'stu02','2022-08-18','teacher01',-3,11,'7003850'),(56,'태도 우수',5,'stu01','2022-08-18','teacher01',-6,52,'7003850'),(57,'과제 점수',3,'stu02','2022-08-18','teacher01',-3,14,'7003850'),(58,'그냥 모범생임',10,'coach_stu','2022-08-18','coach_teach',0,10,'7003850'),(59,'1',-10,'coach_stu','2022-08-18','coach_teach',-10,10,'7003850'),(60,'템구매하게 해줄려고',10,'coach_stu','2022-08-18','ehddb2252',-10,20,'7003850'),(61,'템구매 희망',10,'coach_stu','2022-08-18','ehddb2252',-10,30,'7003850'),(62,'템구매',10,'coach_stu','2022-08-18','ehddb2252',-10,40,'7003850'),(63,'ㅁㅁ',10,'coach_stu','2022-08-18','ehddb2252',-10,20,'7003850'),(64,'ㅁㅁ',10,'coach_stu','2022-08-18','ehddb2252',-10,30,'7003850'),(65,'ㅁㅁ',10,'coach_stu','2022-08-18','ehddb2252',-10,40,'7003850'),(66,'ㅁㅁ',10,'coach_stu','2022-08-18','ehddb2252',-10,50,'7003850'),(67,'모쌩김',-10,'Ejddb2252','2022-08-18','tontonyufriendjyp',-10,0,'7003850'),(68,'과제 점수',3,'stu01','2022-08-19','teacher01',-6,55,'7003850'),(69,'과제 점수',-1,'stu08','2022-08-19','teacher01',-1,2,'7003850'),(70,'과제 점수',-1,'stu07','2022-08-19','teacher01',-1,0,'7003850'),(71,'과제 점수',-1,'stu06','2022-08-19','teacher01',-1,0,'7003850'),(72,'과제 점수',3,'stu02','2022-08-19','teacher01',-3,17,'7003850'),(73,'학업 우수',10,'consultant_stu','2022-08-19','consultant_teach',0,10,'7003850'),(74,'봉사활동',10,'consultant_stu','2022-08-19','consultant_teach',0,20,'7003850'),(75,'태도 우수',10,'consultant_stu','2022-08-19','consultant_teach',0,30,'7003850'),(76,'성적 우수',10,'consultant_stu','2022-08-19','consultant_teach',0,40,'7003850'),(77,'과제 점수',10,'consultant_stu','2022-08-19','consultant_teach',0,10,'7003850');
/*!40000 ALTER TABLE `accounts_pointlog` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-08-19 10:03:15
