-- MySQL dump 10.13  Distrib 8.0.28, for Win64 (x86_64)
--
-- Host: 3.36.69.192    Database: educolab
-- ------------------------------------------------------
-- Server version	8.0.30-0ubuntu0.20.04.2

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `homework_studenthomework`
--

DROP TABLE IF EXISTS `homework_studenthomework`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `homework_studenthomework` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `title` varchar(45) NOT NULL,
  `content` longtext NOT NULL,
  `created_at` datetime(6) NOT NULL,
  `updated_at` datetime(6) NOT NULL,
  `deadline` date NOT NULL,
  `agreement` tinyint(1) NOT NULL,
  `student_id` varchar(20) NOT NULL,
  `submit_flag` tinyint(1) NOT NULL,
  `teacher_id` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `homework_studenthome_student_id_711edc22_fk_accounts_` (`student_id`),
  KEY `homework_studenthome_teacher_id_165e91a1_fk_accounts_` (`teacher_id`),
  CONSTRAINT `homework_studenthome_student_id_711edc22_fk_accounts_` FOREIGN KEY (`student_id`) REFERENCES `accounts_userinfo` (`username`),
  CONSTRAINT `homework_studenthome_teacher_id_165e91a1_fk_accounts_` FOREIGN KEY (`teacher_id`) REFERENCES `accounts_userinfo` (`username`)
) ENGINE=InnoDB AUTO_INCREMENT=34 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `homework_studenthomework`
--

LOCK TABLES `homework_studenthomework` WRITE;
/*!40000 ALTER TABLE `homework_studenthomework` DISABLE KEYS */;
INSERT INTO `homework_studenthomework` VALUES (24,'0818 수학 자율학습 (에라토스테네스의 체)','에라토스테네스의 체에 대해서 정리해 보도록 하겠습니다.','2022-08-18 07:45:23.988985','2022-08-18 15:26:15.697672','2022-08-24',0,'stu02',0,'consultant_teach'),(25,'국어 자율 학습','.','2022-08-18 08:21:59.118095','2022-08-18 22:37:02.712777','2022-08-15',0,'stu01',1,'consultant_teach'),(26,'수학 자율 학습','시도','2022-08-18 13:03:25.654974','2022-08-18 22:37:09.082047','2022-08-23',0,'stu01',0,'consultant_teach'),(27,'0818 수학 자율학습 (에라토스테네스의 체)','에라토스테네스의 체에 대해서 정리해 보도록 하겠습니다.','2022-08-18 13:08:41.297018','2022-08-18 13:08:41.297054','2022-08-24',0,'stu02',0,'consultant_teach'),(28,'오늘의 문제','우선 과제 등록 시도해봅니다','2022-08-18 13:50:09.926116','2022-08-18 13:50:09.926153','2022-08-23',0,'stu03',0,'consultant_teach'),(29,'자율 학습 수학 (에라토스테네스)','에라토스테네스 체에 대해서 설명해 보세요','2022-08-18 15:22:37.485579','2022-08-18 15:22:37.485616','2022-08-25',0,'stu02',0,'consultant_teach'),(30,'ㅁㄴㅇㄹ','ㅁㄴㅇㄹ','2022-08-18 15:24:57.969980','2022-08-18 15:24:57.970014','2022-08-25',0,'stu02',0,'consultant_teach'),(31,'자율학습 과제','자율학습 하겠습니다.','2022-08-18 17:16:32.357730','2022-08-18 17:16:32.357768','2022-08-20',0,'consultant_stu',0,'consultant_teach'),(32,'수학 공부','수학 문제짐 3Page 풀겠습니다.','2022-08-18 17:16:54.436621','2022-08-18 17:17:44.488616','2022-08-21',0,'consultant_stu',1,'consultant_teach'),(33,'수학 공부','수학 문제집 3page 풀겠습니다.','2022-08-18 17:18:45.875302','2022-08-18 17:19:26.917958','2022-08-22',0,'consultant_stu',1,'consultant_teach');
/*!40000 ALTER TABLE `homework_studenthomework` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-08-19 10:03:05
