-- MySQL dump 10.13  Distrib 8.0.28, for Win64 (x86_64)
--
-- Host: 3.36.69.192    Database: educolab
-- ------------------------------------------------------
-- Server version	8.0.30-0ubuntu0.20.04.2

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `accounts_userinfo_own_title`
--

DROP TABLE IF EXISTS `accounts_userinfo_own_title`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `accounts_userinfo_own_title` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `userinfo_id` varchar(20) NOT NULL,
  `ptitle_id` bigint NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `accounts_userinfo_own_title_userinfo_id_title_id_b55ebc22_uniq` (`userinfo_id`,`ptitle_id`),
  KEY `accounts_userinfo_ow_ptitle_id_6f8ab53d_fk_pointshop` (`ptitle_id`),
  CONSTRAINT `accounts_userinfo_ow_ptitle_id_6f8ab53d_fk_pointshop` FOREIGN KEY (`ptitle_id`) REFERENCES `pointshop_ptitle` (`id`),
  CONSTRAINT `accounts_userinfo_ow_userinfo_id_31914d49_fk_accounts_` FOREIGN KEY (`userinfo_id`) REFERENCES `accounts_userinfo` (`username`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `accounts_userinfo_own_title`
--

LOCK TABLES `accounts_userinfo_own_title` WRITE;
/*!40000 ALTER TABLE `accounts_userinfo_own_title` DISABLE KEYS */;
INSERT INTO `accounts_userinfo_own_title` VALUES (12,'consultant_stu',7),(13,'consultant_stu',8),(9,'Ejddb2252',8),(6,'stu01',1),(1,'stu01',2),(5,'stu01',3),(7,'stu01',7),(8,'stu01',8),(14,'stu04',1),(11,'stu05',4),(10,'stu05',7);
/*!40000 ALTER TABLE `accounts_userinfo_own_title` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-08-19 10:03:19
