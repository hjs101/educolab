-- MySQL dump 10.13  Distrib 8.0.28, for Win64 (x86_64)
--
-- Host: 3.36.69.192    Database: educolab
-- ------------------------------------------------------
-- Server version	8.0.30-0ubuntu0.20.04.2

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `survey_surveyquestionsanswer`
--

DROP TABLE IF EXISTS `survey_surveyquestionsanswer`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `survey_surveyquestionsanswer` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `content` longtext NOT NULL,
  `question_id` bigint DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `survey_surveyquestio_question_id_4f1a0d3d_fk_survey_su` (`question_id`),
  CONSTRAINT `survey_surveyquestio_question_id_4f1a0d3d_fk_survey_su` FOREIGN KEY (`question_id`) REFERENCES `survey_surveyquestions` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=48 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `survey_surveyquestionsanswer`
--

LOCK TABLES `survey_surveyquestionsanswer` WRITE;
/*!40000 ALTER TABLE `survey_surveyquestionsanswer` DISABLE KEYS */;
INSERT INTO `survey_surveyquestionsanswer` VALUES (16,'영어 수업이 너무 지루해요',147),(17,'너무 중구난방으로 수업해서 잘 못따라가겠어요!',147),(18,'이 문제좀 가르쳐주세요. I\'m the top class ...',147),(19,'차라리 혼자 공부하는 게 낫겠어요...',147),(20,'너무 졸려서 저도 모르게 잠들었어요',147),(21,'싸피만세',147),(22,'조동사 배우는데 교과서에 나오는 민수의 조동아리를 꿰메고 싶어요',147),(27,'미역국에 밥 말아먹었어요',223),(28,'햄버거',223),(29,'육전 시래기국ㅎ',223),(30,'밥을먹었는데요?',223),(31,'라면이요',223),(32,'피자',223),(33,'간장계란밥',223),(34,'fgtrtyg',196),(35,'44rsdyuu',197),(36,'rtji',223),(38,'햄버거요',314),(39,'피자용',314),(40,'맛있는미역국',314),(41,'삼겹살',314),(42,'초밥',314),(43,'카레라이스',314),(44,'짜장면',314),(45,'국밥',314),(46,'랍스타',314),(47,'순천만정원박람회가그렇게이쁘다던데',179);
/*!40000 ALTER TABLE `survey_surveyquestionsanswer` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-08-19 10:03:13
