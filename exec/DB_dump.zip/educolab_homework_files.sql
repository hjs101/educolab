-- MySQL dump 10.13  Distrib 8.0.28, for Win64 (x86_64)
--
-- Host: 3.36.69.192    Database: educolab
-- ------------------------------------------------------
-- Server version	8.0.30-0ubuntu0.20.04.2

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `homework_files`
--

DROP TABLE IF EXISTS `homework_files`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `homework_files` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `atch_file_name` varchar(45) NOT NULL,
  `atch_file` varchar(100) NOT NULL,
  `student_homework_id` bigint DEFAULT NULL,
  `teacher_homework_id` bigint DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `homework_files_student_homework_id_d053f693_fk_homework_` (`student_homework_id`),
  KEY `homework_files_teacher_homework_id_2a41c2b5_fk_homework_` (`teacher_homework_id`),
  CONSTRAINT `homework_files_student_homework_id_d053f693_fk_homework_` FOREIGN KEY (`student_homework_id`) REFERENCES `homework_studenthomework` (`id`),
  CONSTRAINT `homework_files_teacher_homework_id_2a41c2b5_fk_homework_` FOREIGN KEY (`teacher_homework_id`) REFERENCES `homework_teacherhomework` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=57 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `homework_files`
--

LOCK TABLES `homework_files` WRITE;
/*!40000 ALTER TABLE `homework_files` DISABLE KEYS */;
INSERT INTO `homework_files` VALUES (39,'0810국어과제.zip','homework/create/0810국어과제.zip',NULL,57),(40,'0810국어과제.zip','homework/create/0810국어과제_QPxUAgC.zip',NULL,58),(41,'0810국어과제.zip','homework/create/0810국어과제_ljY0RTE.zip',NULL,59),(44,'소인수 분해 문제.hwp','homework/create/소인수_분해_문제.hwp',NULL,61),(45,'최대 공약수 문제.hwp','homework/create/최대_공약수_문제.hwp',NULL,62),(46,'0818기술가정 디자인해오기.zip','homework/create/0818기술가정_디자인해오기.zip',NULL,67),(47,'풀이.md','homework/create/풀이.md',NULL,66),(48,'풀이.md','homework/create/풀이.md',NULL,95),(51,'0818기술가정 디자인해오기.zip','homework/create/0818기술가정_디자인해오기_NKrDRmV.zip',NULL,96),(52,'최소 공배수 문제.hwp','homework/create/최소_공배수_문제.hwp',NULL,63),(53,'방정식 문제.hwp','homework/create/방정식_문제.hwp',NULL,65);
/*!40000 ALTER TABLE `homework_files` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-08-19 10:03:06
