-- MySQL dump 10.13  Distrib 8.0.28, for Win64 (x86_64)
--
-- Host: 3.36.69.192    Database: educolab
-- ------------------------------------------------------
-- Server version	8.0.30-0ubuntu0.20.04.2

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `auth_permission`
--

DROP TABLE IF EXISTS `auth_permission`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `auth_permission` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `content_type_id` int NOT NULL,
  `codename` varchar(100) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `auth_permission_content_type_id_codename_01ab375a_uniq` (`content_type_id`,`codename`),
  CONSTRAINT `auth_permission_content_type_id_2f476e4b_fk_django_co` FOREIGN KEY (`content_type_id`) REFERENCES `django_content_type` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=141 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auth_permission`
--

LOCK TABLES `auth_permission` WRITE;
/*!40000 ALTER TABLE `auth_permission` DISABLE KEYS */;
INSERT INTO `auth_permission` VALUES (1,'Can add survey list',1,'add_surveylist'),(2,'Can change survey list',1,'change_surveylist'),(3,'Can delete survey list',1,'delete_surveylist'),(4,'Can view survey list',1,'view_surveylist'),(5,'Can add survey questions',2,'add_surveyquestions'),(6,'Can change survey questions',2,'change_surveyquestions'),(7,'Can delete survey questions',2,'delete_surveyquestions'),(8,'Can view survey questions',2,'view_surveyquestions'),(9,'Can add survey questions answer',3,'add_surveyquestionsanswer'),(10,'Can change survey questions answer',3,'change_surveyquestionsanswer'),(11,'Can delete survey questions answer',3,'delete_surveyquestionsanswer'),(12,'Can view survey questions answer',3,'view_surveyquestionsanswer'),(13,'Can add suevey template',4,'add_sueveytemplate'),(14,'Can change suevey template',4,'change_sueveytemplate'),(15,'Can delete suevey template',4,'delete_sueveytemplate'),(16,'Can view suevey template',4,'view_sueveytemplate'),(17,'Can add notice',5,'add_notice'),(18,'Can change notice',5,'change_notice'),(19,'Can delete notice',5,'delete_notice'),(20,'Can view notice',5,'view_notice'),(21,'Can add files',6,'add_files'),(22,'Can change files',6,'change_files'),(23,'Can delete files',6,'delete_files'),(24,'Can view files',6,'view_files'),(25,'Can add school info',7,'add_schoolinfo'),(26,'Can change school info',7,'change_schoolinfo'),(27,'Can delete school info',7,'delete_schoolinfo'),(28,'Can view school info',7,'view_schoolinfo'),(29,'Can add user',8,'add_userinfo'),(30,'Can change user',8,'change_userinfo'),(31,'Can delete user',8,'delete_userinfo'),(32,'Can view user',8,'view_userinfo'),(33,'Can add site',9,'add_site'),(34,'Can change site',9,'change_site'),(35,'Can delete site',9,'delete_site'),(36,'Can view site',9,'view_site'),(37,'Can add social application',10,'add_socialapp'),(38,'Can change social application',10,'change_socialapp'),(39,'Can delete social application',10,'delete_socialapp'),(40,'Can view social application',10,'view_socialapp'),(41,'Can add social account',11,'add_socialaccount'),(42,'Can change social account',11,'change_socialaccount'),(43,'Can delete social account',11,'delete_socialaccount'),(44,'Can view social account',11,'view_socialaccount'),(45,'Can add social application token',12,'add_socialtoken'),(46,'Can change social application token',12,'change_socialtoken'),(47,'Can delete social application token',12,'delete_socialtoken'),(48,'Can view social application token',12,'view_socialtoken'),(49,'Can add email address',13,'add_emailaddress'),(50,'Can change email address',13,'change_emailaddress'),(51,'Can delete email address',13,'delete_emailaddress'),(52,'Can view email address',13,'view_emailaddress'),(53,'Can add email confirmation',14,'add_emailconfirmation'),(54,'Can change email confirmation',14,'change_emailconfirmation'),(55,'Can delete email confirmation',14,'delete_emailconfirmation'),(56,'Can view email confirmation',14,'view_emailconfirmation'),(57,'Can add Token',15,'add_token'),(58,'Can change Token',15,'change_token'),(59,'Can delete Token',15,'delete_token'),(60,'Can view Token',15,'view_token'),(61,'Can add token',16,'add_tokenproxy'),(62,'Can change token',16,'change_tokenproxy'),(63,'Can delete token',16,'delete_tokenproxy'),(64,'Can view token',16,'view_tokenproxy'),(65,'Can add log entry',17,'add_logentry'),(66,'Can change log entry',17,'change_logentry'),(67,'Can delete log entry',17,'delete_logentry'),(68,'Can view log entry',17,'view_logentry'),(69,'Can add permission',18,'add_permission'),(70,'Can change permission',18,'change_permission'),(71,'Can delete permission',18,'delete_permission'),(72,'Can view permission',18,'view_permission'),(73,'Can add group',19,'add_group'),(74,'Can change group',19,'change_group'),(75,'Can delete group',19,'delete_group'),(76,'Can view group',19,'view_group'),(77,'Can add content type',20,'add_contenttype'),(78,'Can change content type',20,'change_contenttype'),(79,'Can delete content type',20,'delete_contenttype'),(80,'Can view content type',20,'view_contenttype'),(81,'Can add session',21,'add_session'),(82,'Can change session',21,'change_session'),(83,'Can delete session',21,'delete_session'),(84,'Can view session',21,'view_session'),(85,'Can add point log',22,'add_pointlog'),(86,'Can change point log',22,'change_pointlog'),(87,'Can delete point log',22,'delete_pointlog'),(88,'Can view point log',22,'view_pointlog'),(89,'Can add student homework',23,'add_studenthomework'),(90,'Can change student homework',23,'change_studenthomework'),(91,'Can delete student homework',23,'delete_studenthomework'),(92,'Can view student homework',23,'view_studenthomework'),(93,'Can add teacher homework',24,'add_teacherhomework'),(94,'Can change teacher homework',24,'change_teacherhomework'),(95,'Can delete teacher homework',24,'delete_teacherhomework'),(96,'Can view teacher homework',24,'view_teacherhomework'),(97,'Can add submit homework',25,'add_submithomework'),(98,'Can change submit homework',25,'change_submithomework'),(99,'Can delete submit homework',25,'delete_submithomework'),(100,'Can view submit homework',25,'view_submithomework'),(101,'Can add files',26,'add_files'),(102,'Can change files',26,'change_files'),(103,'Can delete files',26,'delete_files'),(104,'Can view files',26,'view_files'),(105,'Can add time line',27,'add_timeline'),(106,'Can change time line',27,'change_timeline'),(107,'Can delete time line',27,'delete_timeline'),(108,'Can view time line',27,'view_timeline'),(109,'Can add event',28,'add_event'),(110,'Can change event',28,'change_event'),(111,'Can delete event',28,'delete_event'),(112,'Can view event',28,'view_event'),(113,'Can add quiz list',29,'add_quizlist'),(114,'Can change quiz list',29,'change_quizlist'),(115,'Can delete quiz list',29,'delete_quizlist'),(116,'Can view quiz list',29,'view_quizlist'),(117,'Can add quiz questions',30,'add_quizquestions'),(118,'Can change quiz questions',30,'change_quizquestions'),(119,'Can delete quiz questions',30,'delete_quizquestions'),(120,'Can view quiz questions',30,'view_quizquestions'),(121,'Can add p title',31,'add_ptitle'),(122,'Can change p title',31,'change_ptitle'),(123,'Can delete p title',31,'delete_ptitle'),(124,'Can view p title',31,'view_ptitle'),(125,'Can add icon',32,'add_icon'),(126,'Can change icon',32,'change_icon'),(127,'Can delete icon',32,'delete_icon'),(128,'Can view icon',32,'view_icon'),(129,'Can add quiz room',33,'add_quizroom'),(130,'Can change quiz room',33,'change_quizroom'),(131,'Can delete quiz room',33,'delete_quizroom'),(132,'Can view quiz room',33,'view_quizroom'),(133,'Can add quiz user',34,'add_quizuser'),(134,'Can change quiz user',34,'change_quizuser'),(135,'Can delete quiz user',34,'delete_quizuser'),(136,'Can view quiz user',34,'view_quizuser'),(137,'Can add quiz answer',35,'add_quizanswer'),(138,'Can change quiz answer',35,'change_quizanswer'),(139,'Can delete quiz answer',35,'delete_quizanswer'),(140,'Can view quiz answer',35,'view_quizanswer');
/*!40000 ALTER TABLE `auth_permission` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-08-19 10:03:10
