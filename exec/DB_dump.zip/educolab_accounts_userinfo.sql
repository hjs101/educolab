-- MySQL dump 10.13  Distrib 8.0.28, for Win64 (x86_64)
--
-- Host: 3.36.69.192    Database: educolab
-- ------------------------------------------------------
-- Server version	8.0.30-0ubuntu0.20.04.2

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `accounts_userinfo`
--

DROP TABLE IF EXISTS `accounts_userinfo`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `accounts_userinfo` (
  `password` varchar(128) NOT NULL,
  `last_login` datetime(6) DEFAULT NULL,
  `is_superuser` tinyint(1) NOT NULL,
  `first_name` varchar(150) NOT NULL,
  `last_name` varchar(150) NOT NULL,
  `email` varchar(254) NOT NULL,
  `is_staff` tinyint(1) NOT NULL,
  `is_active` tinyint(1) NOT NULL,
  `date_joined` datetime(6) NOT NULL,
  `username` varchar(20) NOT NULL,
  `userflag` tinyint(1) NOT NULL,
  `name` varchar(30) NOT NULL,
  `birthday` date NOT NULL,
  `phone_number` varchar(11) NOT NULL,
  `grade` int DEFAULT NULL,
  `class_field` int DEFAULT NULL,
  `subject` varchar(20) DEFAULT NULL,
  `homeroom_teacher_flag` int DEFAULT NULL,
  `plus_point` int NOT NULL,
  `minus_point` int NOT NULL,
  `profil` varchar(100) NOT NULL,
  `school` varchar(7) NOT NULL,
  `acc_point` int DEFAULT NULL,
  `wear_title_id` bigint DEFAULT NULL,
  `wear_icon_id` bigint DEFAULT NULL,
  PRIMARY KEY (`username`),
  KEY `accounts_userinfo_school_1667a02f_fk_accounts_schoolinfo_code` (`school`),
  KEY `accounts_userinfo_wear_title_id_09fcb635_fk_pointshop_ptitle_id` (`wear_title_id`),
  KEY `accounts_userinfo_wear_icon_id_1f36bb7c_fk_pointshop_icon_id` (`wear_icon_id`),
  CONSTRAINT `accounts_userinfo_school_1667a02f_fk_accounts_schoolinfo_code` FOREIGN KEY (`school`) REFERENCES `accounts_schoolinfo` (`code`),
  CONSTRAINT `accounts_userinfo_wear_icon_id_1f36bb7c_fk_pointshop_icon_id` FOREIGN KEY (`wear_icon_id`) REFERENCES `pointshop_icon` (`id`),
  CONSTRAINT `accounts_userinfo_wear_title_id_09fcb635_fk_pointshop_ptitle_id` FOREIGN KEY (`wear_title_id`) REFERENCES `pointshop_ptitle` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `accounts_userinfo`
--

LOCK TABLES `accounts_userinfo` WRITE;
/*!40000 ALTER TABLE `accounts_userinfo` DISABLE KEYS */;
INSERT INTO `accounts_userinfo` VALUES ('pbkdf2_sha256$260000$GLGFzhDLAichhbh8J1xSm7$KKiOZmIh3D+t2NcMogDOri7CbqnSve47RLzTMn1IcE8=','2022-08-18 06:03:25.894802',0,'','','test523@test.com',0,1,'2022-08-18 06:03:25.681061','coach_stu',0,'김동유','2008-03-12','01089435424',1,5,NULL,NULL,0,-10,'accounts/profils/profile1.jpg','7003850',80,NULL,22),('pbkdf2_sha256$260000$gYXhnU6E7Cln9jXkWxaU8t$sv4ZwQ59vF8XrTj+m9aLFCEEBzC9zvNjwnZKOrsg2so=','2022-08-18 05:29:26.420209',0,'','','coach_teach@gmail.com',0,1,'2022-08-18 05:29:26.209065','coach_teach',1,'하현서','2000-06-16','01012345678',NULL,NULL,'국어',0,0,0,'accounts/profils/profile1.jpg','7003850',0,NULL,NULL),('pbkdf2_sha256$260000$uvEgM8u7xohbMDoUjSRi38$GgapyAcvBxWF6GT7MBZ2pfiRGzPcEaoByVUfV65FAsA=','2022-08-18 05:38:50.687329',0,'','','consultant_stu@gmail.com',0,1,'2022-08-18 05:38:50.475780','consultant_stu',0,'김성준','2008-05-07','01012344321',1,5,NULL,NULL,10,0,'accounts/profils/game01_98_4dZl6gG.jpg','7003850',50,8,14),('pbkdf2_sha256$260000$YrJ2JXigOcwq0qUuOSDcDs$QwOU0UDFbk8adNc764+M88Fue2yzs4Lfwj6MVzIInzQ=','2022-08-18 05:37:52.872407',0,'','','consultant_teach@gmail.com',0,1,'2022-08-18 05:37:52.660963','consultant_teach',1,'김성준','1972-01-01','01012341234',1,5,'수학',1,0,0,'accounts/profils/profile1.jpg','7003850',0,NULL,NULL),('pbkdf2_sha256$260000$gVdyWtdhcMFOTkiyBwPkaT$8fQsRoQ9OgMqnl0KkL/cknfVKHvP+7BpA9AruDaaUXs=','2022-08-03 02:06:41.179615',0,'','','pubhan35@gmail.com',0,1,'2022-08-03 02:06:40.829824','dkdlel',0,'나원경','2008-01-01','93840974023',1,5,NULL,NULL,500,0,'accounts/profils/profile1.jpg','7391151',0,NULL,NULL),('pbkdf2_sha256$260000$8LzchKG9psmzWyZ6GSXCHs$BbpllKqTfvqZxG8Z5ATZbcKJxV1fvuWs24uWigReZ3U=','2022-08-09 03:42:30.141310',0,'','','ehddb2252@gmail.com',0,1,'2022-08-09 03:42:29.926585','ehddb2252',1,'김동유','1995-02-19','01000000000',NULL,NULL,'수학',0,0,0,'accounts/profils/profile1.jpg','7003850',0,NULL,NULL),('pbkdf2_sha256$260000$n2RyoKzfUknVQKYxU1dcuu$M2W0tbDbrCrxmXew9c7AKoZlZDIFvBLzFD3DmDmdvBc=','2022-08-09 03:45:40.712376',0,'','','ehddb2252@naver.com',0,1,'2022-08-09 03:45:40.501830','Ejddb2252',0,'김동유','2008-01-01','01000000000',1,5,NULL,NULL,0,-10,'accounts/profils/profile1.jpg','7003850',0,NULL,NULL),('pbkdf2_sha256$260000$wU71l2EtEuZNBBuSzSXjZ0$o1yHBvQVEogJ/Bxff7YinT64u0XASP7rvMZ3/LP4nFY=','2022-08-16 19:35:36.966691',0,'','','h5282000@naver.com',0,1,'2022-08-16 19:35:36.728421','h5282000',1,'마동탁','1972-01-01','01011234123',NULL,NULL,'기술가정',NULL,0,0,'accounts/profils/profile1.jpg','7003850',0,NULL,NULL),('pbkdf2_sha256$260000$NijnTwMjgMLqjXtBcLnSbE$ERdrKirrsKTmMQJATnIwU1ga8O4qlW7Wqs7P0Veg8EE=','2022-08-18 19:48:11.479522',0,'','','gkswlstjdwkd@naver.com',0,1,'2022-08-18 19:48:11.261216','h5282001',0,'한진상','2008-01-16','01012341234',1,5,NULL,NULL,0,0,'accounts/profils/profile1.jpg','7003850',0,NULL,NULL),('pbkdf2_sha256$260000$FrzLi6ax5wgvBJJ2yz2tER$/U/sxKqqGRqurBfbZtfzEaiY4WQmxIX8STPyKCavTX0=','2022-08-18 05:56:06.447273',0,'','','tekjhs8@teha.com',0,1,'2022-08-18 05:56:06.235318','onefourone',0,'이사일','2008-11-11','01087357321',1,4,NULL,NULL,0,0,'accounts/profils/profile1.jpg','7003850',0,NULL,NULL),('pbkdf2_sha256$260000$jFfuKZ77KEmjwtxEe6DOFV$5Uo3O+nuI0pwMwimxKKpcqu+WgrUHkKVDcev0Q3mC1Y=','2022-08-18 06:01:24.858687',0,'','','teas2@test.com',0,1,'2022-08-18 06:01:24.648169','onefourtwo',0,'이사이','2008-05-05','01034841215',1,4,NULL,NULL,0,0,'accounts/profils/profile1.jpg','7003850',0,NULL,NULL),('pbkdf2_sha256$260000$JLmFsWYGzF3SeHvXltBKZl$fCTmgzKUoVEQ1yP/wh3IIBp2KHlH8QY8+OTEpbLqNwk=','2022-08-18 05:52:36.087920',0,'','','test2@test.com',0,1,'2022-08-18 05:52:35.871996','onethreeone',0,'이일삼','2008-01-03','01012345678',1,3,NULL,NULL,0,0,'accounts/profils/profile1.jpg','7003850',0,NULL,NULL),('pbkdf2_sha256$260000$sG7ku4SQzRlux8jPOyhDYz$+gD7XFl+cP4gh0IAh9zL2Okx+0nkagn2wXdl8WFOxoo=','2022-08-18 05:55:03.007502',0,'','','testi82@test.com',0,1,'2022-08-18 05:55:02.793012','onethreeth',0,'이삼삼','2008-06-16','01083524832',1,3,NULL,NULL,0,0,'accounts/profils/profile1.jpg','7003850',0,NULL,NULL),('pbkdf2_sha256$260000$QPYrfJLIgXrpiosOMXK8FW$PaBcTJN1qRQ3v9wxCCQO1xqnhvmZe2AOuGV8K6gx9F4=','2022-08-18 05:53:53.302934',0,'','','test52@gmail.com',0,1,'2022-08-18 05:53:53.092983','onethreetwo',0,'이삼일','2008-07-02','01012567821',1,3,NULL,NULL,0,0,'accounts/profils/profile1.jpg','7003850',0,NULL,NULL),('pbkdf2_sha256$260000$1rMQSa3FGMToCvQb6JQ14T$p2L8IL/LEUZvKPwSB73AeX0nwWviTRXz+AFiKNVO/D0=','2022-08-17 10:45:08.540736',0,'','','test@test.com',0,1,'2022-08-17 10:45:08.326350','sal0203',0,'홍찬기','2008-07-02','01090255890',1,5,NULL,NULL,0,0,'accounts/profils/profile1.jpg','7561008',0,NULL,NULL),('pbkdf2_sha256$260000$tbFWV7Az4HiezaFybQ1EEL$cEIcIhj9/8P3rjbVnIJWGW5oUYYC5gAzvzkEKciLUBQ=','2022-08-02 04:35:03.828430',0,'','','stu01@stu3.co.kr',0,1,'2022-08-02 04:35:03.525762','stu01',0,'여동준','2008-01-10','01012341234',1,5,NULL,NULL,55,-6,'accounts/profils/cat3.png','7003850',745,3,2),('pbkdf2_sha256$260000$pu0PSVrqKeqoc3wii9ium9$WvPJDHEr6ukcGkVe3+8nQu4oXNyVv2ygcMw0H/IJIxg=','2022-08-02 04:35:12.293311',0,'','','stu02@stu.com',0,1,'2022-08-02 04:35:11.996691','stu02',0,'홍찬기','2008-01-01','01012341234',1,5,NULL,NULL,17,-3,'accounts/profils/profile1.jpg','7003850',47,NULL,2),('pbkdf2_sha256$260000$O3T2W1uQpjEpHXroPLOKH7$DmCFOj48/or5C9RoMckJBOiS41VpzusuMwWfsy7JKIM=','2022-08-02 04:35:18.917008',0,'','','stu03@stu.com',0,1,'2022-08-02 04:35:18.632930','stu03',0,'나원경','2008-01-01','01012341234',1,5,NULL,NULL,500,-3,'accounts/profils/profile1.jpg','7003850',35,NULL,2),('pbkdf2_sha256$260000$2cGapqCc7FUk8XEu9NxdwI$LFh54Y86c1JaX2yvuFiMVuPgX2ItQ/jm+Hc0ugqAdNw=','2022-08-02 04:35:41.631244',0,'','','stu04@stu.com',0,1,'2022-08-02 04:35:41.349927','stu04',0,'정석호','2008-01-01','01012341234',1,5,NULL,NULL,370,0,'accounts/profils/이미지파일.jpg','7003850',0,1,24),('pbkdf2_sha256$260000$XeEpzyQDDWaTqsrUrJkJ1Y$7e0Xl9E9rtxg7EXoNM9zJKKQ1FkvjUfHPPnzn78GAk0=','2022-08-02 15:00:03.192353',0,'','','stu05@stu.com',0,1,'2022-08-02 15:00:02.918079','stu05',0,'한진성','1988-01-01','01012341234',1,5,NULL,NULL,290,-1,'accounts/profils/game01_98_9hcWqtY.jpg','7003850',0,4,NULL),('pbkdf2_sha256$260000$GmYswTlD79m6Mpa9kIZQbB$jvyrEuNCuqR0LPpdj0u87qaOkf5DmzNjIyHL/KmyWpQ=','2022-08-02 16:43:51.906314',0,'','','stu06@stu.com',0,1,'2022-08-02 16:43:51.621261','stu06',0,'학생6','2008-01-01','01012341234',1,5,NULL,NULL,0,-1,'accounts/profils/profile1.jpg','7003850',0,NULL,NULL),('pbkdf2_sha256$260000$XatVDwCJx73F7jhi46ivPa$a7U7f682BeFPVoJKxWK2lM47M2WZ5XKQUDzFVnvlO/4=','2022-08-07 19:28:19.684666',0,'','','stu07@stu.com',0,1,'2022-08-07 19:28:19.411606','stu07',0,'학생7','2008-01-01','01012341234',1,5,NULL,NULL,0,-1,'accounts/profils/profile1.jpg','7003850',0,NULL,NULL),('pbkdf2_sha256$260000$SlMsnqXyMfNbgz2Uwzgy00$76Aq4n0vpPquPFy2SemKh99ysfyvGkq65DwjrZrQVSk=','2022-08-07 19:36:02.168224',0,'','','stu08@stu.com',0,1,'2022-08-07 19:36:01.877296','stu08',0,'학생8','2008-01-01','01012341234',1,5,NULL,NULL,2,-1,'accounts/profils/profile1.jpg','7003850',2,NULL,NULL),('pbkdf2_sha256$260000$CXXGE9opwwjrAzI5WsOUcH$mjeZ/E5l1NpflXq50eBC+WJr3pGZPVqfW6mcMoiglzs=','2022-08-18 04:23:54.022800',0,'','','h5282001@naver.com',0,1,'2022-08-18 04:23:53.807530','teacher00',1,'한진성','1997-05-28','01012341234',NULL,NULL,'국어',NULL,500,0,'accounts/profils/profile1.jpg','7003850',0,NULL,NULL),('pbkdf2_sha256$260000$TGvqhTHGCofFGEV4zA7c3H$OydAXe42AcM4WgWLxy+KgdjPp4z8QbnmvPu+a0VMnrU=','2022-08-02 04:42:49.481585',0,'','','teacher01@stu2.com',0,1,'2022-08-02 04:42:49.230238','teacher01',1,'마동석','1988-01-07','01058741234',NULL,NULL,'기술가정',0,0,0,'accounts/profils/game01_67.gif','7003850',0,NULL,NULL),('pbkdf2_sha256$260000$tOZK7u33bBNndk02DLgJvi$NKSmC8ElhTG9c2Zux+irF+a7/5ZFHrp7TzPDNZV+H8I=','2022-08-02 04:41:44.563532',0,'','','teacher02@stu.com',0,1,'2022-08-02 04:41:44.313743','teacher02',1,'선생2','2008-01-01','01012341234',NULL,NULL,NULL,0,0,0,'accounts/profils/profile1.jpg','7003850',0,NULL,NULL),('pbkdf2_sha256$260000$Iv4BucfLyWXOinX4VkahMr$GTZsUXsfx3Qw+ly9BnVW3rlbgFdnFdA0xVBzXm08dAk=','2022-08-04 00:47:01.241512',0,'','','pubhan3@gmail.com',0,1,'2022-08-04 00:47:00.520205','teacher1',1,'나우너경','1972-01-01','45646466767',NULL,NULL,'보건',0,0,0,'accounts/profils/profile1.jpg','7003850',0,NULL,NULL),('pbkdf2_sha256$260000$en82sa9sXS3dfE3KhlROSH$imBE1zzszVevanc7w3WJ0EWhmg3q9IFME0cKFdI46gc=','2022-08-18 14:15:25.845976',0,'','','codepark21@gmail.com',0,1,'2022-08-18 14:15:25.628115','tontonyufriendjyp',1,'톤톤유친구','2008-03-11','01012342344',NULL,NULL,'수학',NULL,0,0,'accounts/profils/profile1.jpg','7003850',0,NULL,NULL);
/*!40000 ALTER TABLE `accounts_userinfo` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-08-19 10:03:12
