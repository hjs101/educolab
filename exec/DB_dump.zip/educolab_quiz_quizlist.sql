-- MySQL dump 10.13  Distrib 8.0.28, for Win64 (x86_64)
--
-- Host: 3.36.69.192    Database: educolab
-- ------------------------------------------------------
-- Server version	8.0.30-0ubuntu0.20.04.2

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `quiz_quizlist`
--

DROP TABLE IF EXISTS `quiz_quizlist`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `quiz_quizlist` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `title` varchar(45) NOT NULL,
  `created_at` datetime(6) NOT NULL,
  `updated_at` datetime(6) NOT NULL,
  `teacher_id` varchar(20) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `quiz_quizlist_teacher_id_2523f64a_fk_accounts_userinfo_username` (`teacher_id`),
  CONSTRAINT `quiz_quizlist_teacher_id_2523f64a_fk_accounts_userinfo_username` FOREIGN KEY (`teacher_id`) REFERENCES `accounts_userinfo` (`username`)
) ENGINE=InnoDB AUTO_INCREMENT=96 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `quiz_quizlist`
--

LOCK TABLES `quiz_quizlist` WRITE;
/*!40000 ALTER TABLE `quiz_quizlist` DISABLE KEYS */;
INSERT INTO `quiz_quizlist` VALUES (1,'2학년 1반 1교시 국어 퀴즈 문제','2022-08-08 06:57:04.714064','2022-08-15 18:20:20.074288','teacher01'),(4,'깜짝퀴즈04 - 수정','2022-08-08 06:57:33.924746','2022-08-18 20:06:11.534546','teacher01'),(5,'깜짝퀴즈05','2022-08-08 06:57:36.871095','2022-08-08 06:57:36.871095','teacher01'),(6,'깜짝퀴즈06 - 수정','2022-08-08 06:58:03.011805','2022-08-18 20:21:29.564116','teacher01'),(7,'깜짝퀴즈07','2022-08-08 06:58:06.933780','2022-08-18 19:31:21.737498','teacher01'),(8,'깜짝퀴즈08','2022-08-08 06:58:09.974176','2022-08-19 00:04:23.405447','teacher01'),(9,'깜짝퀴즈09','2022-08-08 06:58:12.478705','2022-08-18 19:26:58.370809','teacher01'),(10,'깜짝퀴즈10','2022-08-08 06:58:15.393951','2022-08-18 19:26:13.781688','teacher01'),(67,'수학 깜짝 퀴즈 : 거듭제곱','2022-08-18 07:18:04.180559','2022-08-18 07:18:04.180596','consultant_teach'),(68,'수학 깜짝 퀴즈 : 정수','2022-08-18 07:21:34.241745','2022-08-18 07:21:34.241781','consultant_teach'),(69,'수학 깜짝 퀴즈 : 정수의 대소 관계','2022-08-18 08:09:25.007477','2022-08-18 08:09:25.007518','consultant_teach'),(70,'수학 깜짝 퀴즈 : 1차 방정식','2022-08-18 08:14:55.133102','2022-08-18 08:14:55.133138','consultant_teach'),(71,'SSAFY 퀴즈!!','2022-08-18 10:01:53.576586','2022-08-18 10:01:53.576623','consultant_teach'),(74,'퀴즈 내용 비워놓고 생성 실험','2022-08-18 12:45:19.066039','2022-08-18 12:45:19.066076','teacher01'),(76,'SSAFY 퀴즈!!','2022-08-18 13:40:28.333928','2022-08-18 13:40:28.333972','teacher01'),(84,'SSAFY 상식 퀴즈!!!!','2022-08-18 17:28:37.395937','2022-08-18 21:05:10.411808','consultant_teach');
/*!40000 ALTER TABLE `quiz_quizlist` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-08-19 10:03:22
