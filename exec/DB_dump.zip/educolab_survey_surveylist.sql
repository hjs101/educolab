-- MySQL dump 10.13  Distrib 8.0.28, for Win64 (x86_64)
--
-- Host: 3.36.69.192    Database: educolab
-- ------------------------------------------------------
-- Server version	8.0.30-0ubuntu0.20.04.2

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `survey_surveylist`
--

DROP TABLE IF EXISTS `survey_surveylist`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `survey_surveylist` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `title` varchar(45) NOT NULL,
  `created_at` datetime(6) NOT NULL,
  `updated_at` datetime(6) NOT NULL,
  `grade` int NOT NULL,
  `class_field` int NOT NULL,
  `teacher_id` varchar(20) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `survey_surveylist_teacher_id_2498fad0_fk_accounts_` (`teacher_id`),
  CONSTRAINT `survey_surveylist_teacher_id_2498fad0_fk_accounts_` FOREIGN KEY (`teacher_id`) REFERENCES `accounts_userinfo` (`username`)
) ENGINE=InnoDB AUTO_INCREMENT=141 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `survey_surveylist`
--

LOCK TABLES `survey_surveylist` WRITE;
/*!40000 ALTER TABLE `survey_surveylist` DISABLE KEYS */;
INSERT INTO `survey_surveylist` VALUES (50,'테스트 한번 해보겠습니다.','2022-08-15 17:37:45.398996','2022-08-16 04:01:01.215105',3,1,'teacher01'),(66,'영어 수업 만족도 조사','2022-08-17 06:19:31.782847','2022-08-17 06:19:31.782883',1,5,'teacher01'),(79,'수학 수업 만족도 설문조사','2022-08-17 19:12:08.484270','2022-08-18 02:14:06.851795',1,5,'teacher01'),(82,'시연용 설문조사 입니다.','2022-08-18 02:45:26.084664','2022-08-18 14:43:59.448216',1,5,'teacher01'),(83,'시연용 설문입니다. 3333','2022-08-18 03:00:01.435649','2022-08-18 14:55:03.922580',0,0,'teacher01'),(84,'시연용 설문입니다.ddd','2022-08-18 03:23:46.185201','2022-08-18 14:49:14.419530',0,0,'teacher01'),(88,'테스트','2022-08-18 05:32:08.547987','2022-08-18 14:43:16.334992',1,1,'teacher01'),(89,'희망 수학여행지 수요조사','2022-08-18 06:30:54.891992','2022-08-18 06:30:54.892031',1,5,'consultant_teach'),(91,'교육활동 전반 만족도 설문조사','2022-08-18 06:41:41.091330','2022-08-18 06:41:41.091366',1,5,'consultant_teach'),(92,'영어 수업 만족도 조사','2022-08-18 06:48:23.460429','2022-08-18 06:48:23.460464',1,5,'consultant_teach'),(93,'수학 기말고사 후 설문','2022-08-18 06:57:17.036796','2022-08-18 06:57:17.036831',0,0,'consultant_teach'),(94,'수학 수준 별 수업 만족도 설문조사','2022-08-18 07:00:49.982562','2022-08-18 07:00:49.982597',0,0,'consultant_teach'),(95,'1학년 5반 학급 체험 활동 설문조사','2022-08-18 07:08:47.723623','2022-08-18 07:08:47.723658',1,5,'consultant_teach'),(101,'오늘 점심에는 무엇을 드셨나요?','2022-08-18 13:43:01.337750','2022-08-18 14:39:11.372784',1,5,'teacher01'),(106,'설문조사입력','2022-08-18 14:56:29.398405','2022-08-18 14:56:29.398442',1,5,'teacher01'),(110,'테스트용 입니당','2022-08-18 15:17:54.091442','2022-08-18 17:37:56.619196',1,3,'teacher01'),(134,'오늘은 어떤 점심을 드셨나요???','2022-08-18 16:50:02.609491','2022-08-18 17:36:42.553120',0,0,'consultant_teach'),(135,'공통 프로젝트 만족하셨나요?','2022-08-18 16:57:36.750353','2022-08-18 17:38:26.544765',1,5,'teacher01');
/*!40000 ALTER TABLE `survey_surveylist` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-08-19 10:03:07
