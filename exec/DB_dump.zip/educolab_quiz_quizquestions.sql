-- MySQL dump 10.13  Distrib 8.0.28, for Win64 (x86_64)
--
-- Host: 3.36.69.192    Database: educolab
-- ------------------------------------------------------
-- Server version	8.0.30-0ubuntu0.20.04.2

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `quiz_quizquestions`
--

DROP TABLE IF EXISTS `quiz_quizquestions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `quiz_quizquestions` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `question_number` int NOT NULL,
  `quiz_question` varchar(500) NOT NULL,
  `multiple_bogi` varchar(500) NOT NULL,
  `answer` int NOT NULL,
  `quiz_id` bigint NOT NULL,
  PRIMARY KEY (`id`),
  KEY `quiz_quizquestions_quiz_id_d846128e_fk_quiz_quizlist_id` (`quiz_id`),
  CONSTRAINT `quiz_quizquestions_quiz_id_d846128e_fk_quiz_quizlist_id` FOREIGN KEY (`quiz_id`) REFERENCES `quiz_quizlist` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=159 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `quiz_quizquestions`
--

LOCK TABLES `quiz_quizquestions` WRITE;
/*!40000 ALTER TABLE `quiz_quizquestions` DISABLE KEYS */;
INSERT INTO `quiz_quizquestions` VALUES (1,1,'1 더하기 1은?','2/3/4/5',1,1),(2,2,'2 더하기 2은?','2/3/4/5',3,1),(3,3,'3 더하기 3은?','6/3/4/5',1,1),(13,1,'1 더하기 1은?','2/3/4/5',1,5),(14,2,'2 더하기 2은?','2/3/4/5',3,5),(15,3,'3 더하기 3은?','6/3/4/5',1,5),(69,1,'2⁴ 와 같은 수는 무엇일까요?','16/8/32/18/',1,67),(70,2,'2 x 2 X 2 X 3 X 3 을 거듭제곱의 형태로 맞게 변형한 것은?','2² x 3²/8 x 9/2³ x 3²/3³ x 2²/',3,67),(71,1,'+7, -3, 0, -5, 2 를 양의 정수와 음의 정수로 알맞게 나눈 것은?','양의 정수 : 0, 2, +7, 음의 정수 : -3, -5/양의 정수 : 2, +7, 음의 정수 : -3, -5/양의 정수 2, +7, 음의 정수 : -3, -5, 0/양의 정수 2, +7, -3, -5 음의 정수 0/',2,68),(72,2,'5 - 10의 알맞은 정답은?','5/-5/0/-10/',2,68),(73,1,'-4, -2, +2, 0, 6 을 크기가 작은 것부터 순서대로 나열한 것은?','-4, -2, 0, +2, 6/0, 6, 2, -4, -2/6, 2, 0, -2, -4/-2, -4, 0, 2, 6/',1,69),(74,2,'다음 대소 관계 보기 중 옳은 것은?','-6 > 2/2 > -6/-6 = 2/-2 < -6/',2,69),(75,1,'2x + 3= 9 에서 x 는?','x = 3/x = 4/x = 5/x = 6/',1,70),(76,2,'다음 중 일차방정식은?','2(x+3) = 2x+3/2(x+3) = -2x + 3/x² + x -1 = -x² + x - 1 /x³ + x - 1 = 0 /',1,70),(77,1,'이번 7기 특화 프로젝트에 새롭게 추가된 도메인은 무엇일까요?','블록체인/메타버스/모빌리티/인공지능/',3,71),(78,2,'자바 스크립트에 대한 문제입니다. 다음 보기 중 틀린 것은?','0 == 0 >>> true/0 == [] >>> true/0 == \"0\" >>> true/\"0\" == [] >>> true/',4,71),(79,3,'프로그래밍에 집중한 유연한 개발방식으로 상호작용, SW, 협력, 변화 대응에 가치를 두고 있는 것은?','정보공학/애자일/폭포수/CBD/',2,71),(80,4,'사용자들의 장치와 가까운 데이터 말단부에서 컴퓨팅을 하는 기술로, 클라우드의 단점을 보완하는 것은?','Edge Computing/Emall Computing/End Computing/Terminal Computing/',1,71),(97,1,'이번 7기 특화 프로젝트에 새롭게 추가된 도메인은 무엇일까요?','블록체인/메타버스/모빌리티/ 인공지능/',3,76),(98,2,'자바 스크립트에 대한 문제입니다. 다음 보기 중 틀린 것은?','0 == 0 >>> true/0 == [] >>> true/0 == \"0\" >>> true/\"0\" == [] >>> true/',4,76),(99,3,'프로그래밍에 집중한 유연한 개발방식으로 상호작용, SW, 협력, 변화 대응에 가치를 두고 있는 것은?','정보공학/애자일/폭포수/CBD/',2,76),(100,4,'사용자들의 장치와 가까운 데이터 말단부에서 컴퓨팅을 하는 기술로, 클라우드의 단점을 보완하는 것은?','Edge Computing/Emall Computing/End Computing/Terminal Computing/',1,76),(135,1,'1 빼기 1은?','011/3/4/5',1,10),(136,1,'1 빼기 1은?','02/3/4/5',1,9),(138,1,'1 빼기 1은?','02/3/4/5',1,7),(141,1,'1 더하기 1은?','2/3/4/5',1,4),(142,2,'2 더하기 2은?','2/3/4/5',3,4),(143,3,'3 더하기 3은?','6/3/4/5',1,4),(147,1,'12','1/2/3/4',1,6),(148,2,'1','1/2/3/4',2,6),(149,3,'ㅇㄴㄹㄴㅇㄹ','ㄴㅇㄹㄴㅇ/ㄴㅇㄹㄴㅇ/ㄴㅇㄹㄴㅇ/ㄴㅇㄹㄴㅇ',1,6),(150,1,'SSAFY 캠퍼스가 없는 지역은 어디일까요?','서울/광주/부울경/수원',4,84),(151,2,'입실 체크 마감 시간은 몇 시까지 일까요?','8:00/8:30/9:00/9:30/',3,84),(158,1,'1 빼기 1은?','0/5/6/52',1,8);
/*!40000 ALTER TABLE `quiz_quizquestions` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-08-19 10:03:23
