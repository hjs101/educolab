-- MySQL dump 10.13  Distrib 8.0.28, for Win64 (x86_64)
--
-- Host: 3.36.69.192    Database: educolab
-- ------------------------------------------------------
-- Server version	8.0.30-0ubuntu0.20.04.2

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `survey_surveyquestions`
--

DROP TABLE IF EXISTS `survey_surveyquestions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `survey_surveyquestions` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `question_number` int NOT NULL,
  `survey_question` varchar(500) NOT NULL,
  `multiple_bogi` varchar(500) DEFAULT NULL,
  `num1` int NOT NULL,
  `num2` int NOT NULL,
  `num3` int NOT NULL,
  `num4` int NOT NULL,
  `num5` int NOT NULL,
  `survey_id` bigint NOT NULL,
  PRIMARY KEY (`id`),
  KEY `survey_surveyquestio_survey_id_0ec6ed0d_fk_survey_su` (`survey_id`),
  CONSTRAINT `survey_surveyquestio_survey_id_0ec6ed0d_fk_survey_su` FOREIGN KEY (`survey_id`) REFERENCES `survey_surveylist` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=328 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `survey_surveyquestions`
--

LOCK TABLES `survey_surveyquestions` WRITE;
/*!40000 ALTER TABLE `survey_surveyquestions` DISABLE KEYS */;
INSERT INTO `survey_surveyquestions` VALUES (133,1,'1234','1/2/3/4/',0,0,0,0,0,50),(134,2,'1234',NULL,0,0,0,0,0,50),(145,1,'영어 수업은 학생들의 흥미를 이끄는 요소가 충분하다고 생각하십니까?','매우 만족/만족/보통/불만족/매우 불만족',0,0,1,2,4,66),(146,2,'영어 수업을 들을 때 집중이 잘 되십니까?','매우 잘 됨/잘 됨/보통/안 됨/매우 안됨',0,0,1,3,3,66),(147,3,'영어 수업에 대해 전달하고 싶은 의견이 있다면 적어주시기 바랍니다.',NULL,0,0,0,0,0,66),(166,1,'수학 수업의 난이도는 적합하다고 생각하십니까?','매우 만족/만족/보통/불만족/매우 불만족만족',0,1,0,0,0,79),(178,1,'가고싶은 수항여행지에 투표해주세요','경주/서울/일본/중국/제주도',0,1,0,0,0,89),(179,2,'그 외 가고 싶은 수학 여행지가 있다면 자유롭게 적어주세요',NULL,0,0,0,0,0,89),(183,1,'우리 학교에서 이루어지는 교육 전반적으로 만족스러우신가요?','매우만족/만족/보통/불만족/매우 불만족',0,0,0,0,0,91),(184,2,'수련활동, 행사 등에 대해서 만족스러우신가요?','매우 만족/만족/보통/불만족/매우 불만족',0,0,0,0,0,91),(185,3,'학교 교육 전반적으로 하고싶은 말이 있다면 자유롭게 적어주세요',NULL,0,0,0,0,0,91),(186,1,'수학 수업은 학생들의 흥미를 이끄는 요소가 충분하다고 생각하십니까?','매우 만족/만족/보통/불만족/매우 불만족',0,0,0,0,0,92),(187,2,'수학 수업을 들을 때 집중이 잘 되십니까?','매우 잘 됨/잘 됨/보통/안 됨/매우 안 됨',0,0,0,0,0,92),(188,3,'수학 수업에 대해 전달하고 싶은 의견이 있다면 적어주시기 바랍니다.',NULL,0,0,0,0,0,92),(189,1,'기말고사 수학과목의 난이도는 적절했나요?','매우 만족/만족/보통/불만족/매우 불만족',0,0,0,0,0,93),(190,2,'이번 기말고사 수학 과목에 대해 하고 싶은 말이 있다면 자유롭게 적어주세요',NULL,0,0,0,0,0,93),(191,3,'수학 수업에 대해 전달하고 싶은 의견이 있다면 적어주시기 바랍니다.',NULL,0,0,0,0,0,93),(192,1,'수준 별 수업을 통해 자신에게 알맞은 수업을 들을 수 있었나요?','매우 만족/만족/보통/불만족/매우 불만족',0,0,0,0,0,94),(193,2,'수준 별 수업이 도움이 되었거나 되지 않았다면 그 이유를 적어주세요',NULL,0,0,0,0,0,94),(194,3,'그 외 수학 수업에 대해 하고 싶은 말을 자유롭게 적어주세요.',NULL,0,0,0,0,0,94),(195,1,'원하는 체험 활동을 선택해주세요.','영화 시청/박물관 견학/익스트림 스포츠 : 클라이밍/뮤지컬 관람/직업 체험관 견학',0,1,0,0,0,95),(196,2,'수준 별 수업이 도움이 되었거나 되지 않았다면 그 이유를 적어주세요',NULL,0,0,0,0,0,95),(197,3,'그 외 수학 수업에 대해 하고 싶은 말을 자유롭게 적어주세요.',NULL,0,0,0,0,0,95),(223,1,'어떤 메뉴를 드셨나요?',NULL,0,0,0,0,0,101),(224,2,'점심 메뉴에 대한 만족도는 어떠신가요?','매우 맛있음/맛있음/보통/맛없음/매우 맛없음',3,3,2,0,0,101),(225,3,'삭제할 것',NULL,0,0,0,0,0,88),(226,1,'만족도를 입력해주세요','매우 만족/만족/보통/불만족/매우 불만족',0,0,0,0,0,82),(230,1,'s','s/s/s/s/s',0,0,0,0,0,84),(231,2,'수정 시도','up/d/a/t/e',0,0,0,0,0,84),(238,1,'시연 만족도는 어느정도 입니까?','매우 만족/만족/보통/불만족/매우 불만족',0,0,0,0,0,83),(239,2,'시연에 대해 더 할말이 있나요?',NULL,0,0,0,0,0,83),(240,3,'dfsdf','df/d/f/f/s',0,0,0,0,0,83),(244,1,'시연 만족도는 어느정도 입니까?','매우 만족/만족/보통/불만족/매우 불만족',0,0,0,0,0,106),(245,2,'시연에 대해 더 할말이 있나요?',NULL,0,0,0,0,0,106),(246,3,'dfsdf','df/d/f/f/s',0,0,0,0,0,106),(314,1,'어떤 점심을 드셨나요?',NULL,0,0,0,0,0,134),(315,2,'맛있게 드셨나요?','매우 만족/만족/보통/불만족/매우 불만족',4,3,2,0,0,134),(317,1,'ㅁㄴㅇㄹ','1/2/3/4/5',0,0,0,0,0,110),(318,1,'공통프로젝트에 관해서 의견을 제시해 주세요',NULL,0,0,0,0,0,135);
/*!40000 ALTER TABLE `survey_surveyquestions` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-08-19 10:03:20
