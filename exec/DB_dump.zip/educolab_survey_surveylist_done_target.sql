-- MySQL dump 10.13  Distrib 8.0.28, for Win64 (x86_64)
--
-- Host: 3.36.69.192    Database: educolab
-- ------------------------------------------------------
-- Server version	8.0.30-0ubuntu0.20.04.2

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `survey_surveylist_done_target`
--

DROP TABLE IF EXISTS `survey_surveylist_done_target`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `survey_surveylist_done_target` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `surveylist_id` bigint NOT NULL,
  `userinfo_id` varchar(20) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `survey_surveylist_done_t_surveylist_id_userinfo_i_dca8b949_uniq` (`surveylist_id`,`userinfo_id`),
  KEY `survey_surveylist_do_userinfo_id_f612ad3b_fk_accounts_` (`userinfo_id`),
  CONSTRAINT `survey_surveylist_do_surveylist_id_2beb299f_fk_survey_su` FOREIGN KEY (`surveylist_id`) REFERENCES `survey_surveylist` (`id`),
  CONSTRAINT `survey_surveylist_do_userinfo_id_f612ad3b_fk_accounts_` FOREIGN KEY (`userinfo_id`) REFERENCES `accounts_userinfo` (`username`)
) ENGINE=InnoDB AUTO_INCREMENT=115 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `survey_surveylist_done_target`
--

LOCK TABLES `survey_surveylist_done_target` WRITE;
/*!40000 ALTER TABLE `survey_surveylist_done_target` DISABLE KEYS */;
INSERT INTO `survey_surveylist_done_target` VALUES (41,66,'stu01'),(44,66,'stu02'),(47,66,'stu03'),(50,66,'stu05'),(53,66,'stu06'),(56,66,'stu07'),(59,66,'stu08'),(62,79,'stu01'),(71,79,'stu02'),(65,82,'stu01'),(66,83,'stu01'),(113,89,'consultant_stu'),(88,95,'stu01'),(91,101,'stu01'),(80,101,'stu02'),(75,101,'stu03'),(77,101,'stu05'),(82,101,'stu06'),(84,101,'stu07'),(86,101,'stu08'),(109,134,'onefourone'),(111,134,'onefourtwo'),(95,134,'stu01'),(97,134,'stu02'),(99,134,'stu03'),(101,134,'stu05'),(103,134,'stu06'),(105,134,'stu07'),(107,134,'stu08'),(93,135,'stu01');
/*!40000 ALTER TABLE `survey_surveylist_done_target` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-08-19 10:03:08
