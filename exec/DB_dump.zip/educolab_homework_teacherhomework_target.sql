-- MySQL dump 10.13  Distrib 8.0.28, for Win64 (x86_64)
--
-- Host: 3.36.69.192    Database: educolab
-- ------------------------------------------------------
-- Server version	8.0.30-0ubuntu0.20.04.2

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `homework_teacherhomework_target`
--

DROP TABLE IF EXISTS `homework_teacherhomework_target`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `homework_teacherhomework_target` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `teacherhomework_id` bigint NOT NULL,
  `userinfo_id` varchar(20) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `homework_teacherhomework_teacherhomework_id_useri_787203c7_uniq` (`teacherhomework_id`,`userinfo_id`),
  KEY `homework_teacherhome_userinfo_id_fe7f01ce_fk_accounts_` (`userinfo_id`),
  CONSTRAINT `homework_teacherhome_teacherhomework_id_589f5546_fk_homework_` FOREIGN KEY (`teacherhomework_id`) REFERENCES `homework_teacherhomework` (`id`),
  CONSTRAINT `homework_teacherhome_userinfo_id_fe7f01ce_fk_accounts_` FOREIGN KEY (`userinfo_id`) REFERENCES `accounts_userinfo` (`username`)
) ENGINE=InnoDB AUTO_INCREMENT=611 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `homework_teacherhomework_target`
--

LOCK TABLES `homework_teacherhomework_target` WRITE;
/*!40000 ALTER TABLE `homework_teacherhomework_target` DISABLE KEYS */;
INSERT INTO `homework_teacherhomework_target` VALUES (227,54,'onethreeone'),(228,54,'onethreeth'),(226,54,'onethreetwo'),(229,55,'onefourone'),(230,55,'onefourtwo'),(237,56,'coach_stu'),(231,56,'consultant_stu'),(233,56,'Ejddb2252'),(238,56,'stu01'),(240,56,'stu02'),(239,56,'stu03'),(236,56,'stu05'),(232,56,'stu06'),(234,56,'stu07'),(235,56,'stu08'),(241,57,'onethreeone'),(243,57,'onethreeth'),(242,57,'onethreetwo'),(244,58,'onefourone'),(245,58,'onefourtwo'),(255,59,'coach_stu'),(250,59,'consultant_stu'),(252,59,'Ejddb2252'),(248,59,'stu01'),(254,59,'stu02'),(246,59,'stu03'),(253,59,'stu05'),(247,59,'stu06'),(251,59,'stu07'),(249,59,'stu08'),(256,60,'onethreeone'),(258,60,'onethreeth'),(257,60,'onethreetwo'),(261,61,'coach_stu'),(259,61,'consultant_stu'),(263,61,'Ejddb2252'),(265,61,'stu01'),(267,61,'stu02'),(266,61,'stu03'),(260,61,'stu05'),(262,61,'stu06'),(264,61,'stu07'),(268,61,'stu08'),(271,62,'coach_stu'),(269,62,'consultant_stu'),(273,62,'Ejddb2252'),(275,62,'stu01'),(277,62,'stu02'),(276,62,'stu03'),(270,62,'stu05'),(272,62,'stu06'),(274,62,'stu07'),(278,62,'stu08'),(279,63,'coach_stu'),(284,63,'consultant_stu'),(286,63,'Ejddb2252'),(281,63,'stu01'),(285,63,'stu02'),(280,63,'stu03'),(573,63,'stu04'),(287,63,'stu05'),(283,63,'stu06'),(288,63,'stu07'),(282,63,'stu08'),(304,65,'coach_stu'),(308,65,'consultant_stu'),(300,65,'Ejddb2252'),(307,65,'stu01'),(299,65,'stu02'),(303,65,'stu03'),(574,65,'stu04'),(302,65,'stu05'),(301,65,'stu06'),(305,65,'stu07'),(306,65,'stu08'),(312,67,'coach_stu'),(315,67,'consultant_stu'),(314,67,'Ejddb2252'),(321,67,'stu01'),(316,67,'stu02'),(317,67,'stu03'),(319,67,'stu05'),(313,67,'stu06'),(320,67,'stu07'),(318,67,'stu08'),(334,69,'coach_stu'),(338,69,'consultant_stu'),(340,69,'Ejddb2252'),(333,69,'stu01'),(339,69,'stu02'),(332,69,'stu03'),(336,69,'stu05'),(335,69,'stu06'),(337,69,'stu07'),(341,69,'stu08'),(344,70,'coach_stu'),(348,70,'consultant_stu'),(350,70,'Ejddb2252'),(343,70,'stu01'),(349,70,'stu02'),(342,70,'stu03'),(346,70,'stu05'),(345,70,'stu06'),(347,70,'stu07'),(351,70,'stu08'),(504,89,'coach_stu'),(502,89,'consultant_stu'),(508,89,'Ejddb2252'),(506,89,'stu01'),(509,89,'stu02'),(511,89,'stu03'),(507,89,'stu05'),(510,89,'stu06'),(505,89,'stu07'),(503,89,'stu08'),(514,90,'coach_stu'),(512,90,'consultant_stu'),(518,90,'Ejddb2252'),(516,90,'stu01'),(519,90,'stu02'),(521,90,'stu03'),(517,90,'stu05'),(520,90,'stu06'),(515,90,'stu07'),(513,90,'stu08'),(524,91,'coach_stu'),(522,91,'consultant_stu'),(528,91,'Ejddb2252'),(526,91,'stu01'),(529,91,'stu02'),(531,91,'stu03'),(527,91,'stu05'),(530,91,'stu06'),(525,91,'stu07'),(523,91,'stu08'),(534,92,'coach_stu'),(532,92,'consultant_stu'),(538,92,'Ejddb2252'),(536,92,'stu01'),(539,92,'stu02'),(541,92,'stu03'),(537,92,'stu05'),(540,92,'stu06'),(535,92,'stu07'),(533,92,'stu08'),(562,96,'coach_stu'),(568,96,'consultant_stu'),(564,96,'Ejddb2252'),(566,96,'stu01'),(567,96,'stu02'),(569,96,'stu03'),(570,96,'stu04'),(563,96,'stu05'),(571,96,'stu06'),(572,96,'stu07'),(565,96,'stu08'),(575,97,'coach_stu'),(586,97,'consultant_stu'),(580,97,'Ejddb2252'),(584,97,'h5282001'),(585,97,'stu01'),(576,97,'stu02'),(577,97,'stu03'),(578,97,'stu04'),(579,97,'stu05'),(581,97,'stu06'),(583,97,'stu07'),(582,97,'stu08');
/*!40000 ALTER TABLE `homework_teacherhomework_target` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-08-19 10:03:15
