-- MySQL dump 10.13  Distrib 8.0.28, for Win64 (x86_64)
--
-- Host: 3.36.69.192    Database: educolab
-- ------------------------------------------------------
-- Server version	8.0.30-0ubuntu0.20.04.2

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `homework_teacherhomework`
--

DROP TABLE IF EXISTS `homework_teacherhomework`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `homework_teacherhomework` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `title` varchar(45) NOT NULL,
  `subject` varchar(45) NOT NULL,
  `content` longtext NOT NULL,
  `created_at` datetime(6) NOT NULL,
  `updated_at` datetime(6) NOT NULL,
  `deadline` date NOT NULL,
  `grade` int NOT NULL,
  `class_field` int NOT NULL,
  `teacher_id` varchar(20) NOT NULL,
  `check_flag` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `homework_teacherhome_teacher_id_5cc42f53_fk_accounts_` (`teacher_id`),
  CONSTRAINT `homework_teacherhome_teacher_id_5cc42f53_fk_accounts_` FOREIGN KEY (`teacher_id`) REFERENCES `accounts_userinfo` (`username`)
) ENGINE=InnoDB AUTO_INCREMENT=100 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `homework_teacherhomework`
--

LOCK TABLES `homework_teacherhomework` WRITE;
/*!40000 ALTER TABLE `homework_teacherhomework` DISABLE KEYS */;
INSERT INTO `homework_teacherhomework` VALUES (54,'8월 18일 3반 국어 과제','국어','요즘 학생들이 사용하는 줄임말들을 찾아보고 어떤 뜻이 있는지 찾아오세요.<div>한 사람당 5개 이상 찾아오세요.</div>','2022-08-18 06:28:18.170682','2022-08-18 06:36:34.113057','2022-08-25',1,3,'coach_teach',0),(55,'8월 18일 4반 국어 과제','국어','요즘 학생들이 사용하는 줄임말들을 찾아보고 어떤 뜻이 있는지 찾아오세요.<div>한 사람당 5개 이상 찾아오세요.</div>','2022-08-18 06:29:50.062601','2022-08-18 06:36:44.561962','2022-08-25',1,4,'coach_teach',0),(56,'8월 18일 5반 국어 과제','국어','요즘 학생들이 사용하는 줄임말들을 찾아보고 어떤 뜻이 있는지 찾아오세요.<div>한 사람당 5개 이상 찾아오세요.</div>','2022-08-18 06:30:26.495853','2022-08-18 06:37:22.385763','2022-08-25',1,5,'coach_teach',0),(57,'8월 10일 3반 국어 과제','국어','맞춤법 찾기 숙제입니다.&nbsp;<div>파일 다운받아서 잘못 된 부분 찾아서 고쳐오시면 됩니다.<br><div>8월 17일까지 제출하세요.<div><br></div></div></div>','2022-08-18 07:07:07.873924','2022-08-18 07:07:07.873960','2022-08-17',1,3,'coach_teach',0),(58,'8월 10일 4반 국어 숙제','국어','맞춤법 찾기 숙제입니다.&nbsp;<div>파일 다운받아서 잘못 된 부분 찾아서 고쳐오시면 됩니다.<br><div>8월 17일까지 제출하세요.</div></div>','2022-08-18 07:07:49.459222','2022-08-18 07:07:49.459258','2022-08-17',1,4,'coach_teach',0),(59,'8월 10일 5반 국어 과제','국어','맞춤법 찾기 숙제입니다.&nbsp;<div>파일 다운받아서 잘못 된 부분 찾아서 고쳐오시면 됩니다.<br><div>8월 17일까지 제출하세요.</div></div>','2022-08-18 07:08:14.198974','2022-08-18 07:08:14.199009','2022-08-17',1,5,'coach_teach',0),(60,'기술가정 문제','기술가정','기술 가정 무슨 문제가 있었을까','2022-08-18 10:12:24.794256','2022-08-18 10:18:08.690317','2022-08-22',1,3,'teacher01',0),(61,'소인수 분해 예제 문제','수학','첨부파일을 내려받고 정답을 작성하여 제출하세요.','2022-08-18 11:40:48.230812','2022-08-18 11:40:48.230850','2022-08-19',1,5,'consultant_teach',0),(62,'최대 공약수 문제 예제','수학','첨부파일을 내려받고 정답을 입력해서 다시 제출하세요.','2022-08-18 11:45:14.011816','2022-08-18 11:45:14.011853','2022-08-25',1,5,'consultant_teach',0),(63,'최소 공배수 예제 문제','수학','첨부파일을 내려받아 정답을 입력 후 제출하세요.','2022-08-18 12:00:27.522107','2022-08-18 19:20:11.273902','2022-08-24',1,5,'consultant_teach',0),(65,'일차 방정식 문제','수학','첨부파일을 내려받아 문제를 풀고 답을 입력하여 제출하세요.','2022-08-18 12:44:00.971499','2022-08-18 19:20:24.484740','2022-08-24',1,5,'consultant_teach',0),(66,'과제 수정 시도','기술가정','시도 합니다','2022-08-18 12:50:12.861672','2022-08-18 16:20:59.308261','2022-08-16',1,7,'teacher01',1),(67,'0818 기술가정과','기술가정','다음주까지 디자인해오세요','2022-08-18 12:57:16.927143','2022-08-18 12:57:16.927143','2022-08-25',1,5,'teacher01',0),(69,'기술가정 문제 -- 1','기술가정','기술가정 문제 더미 1','2022-08-18 13:26:31.059289','2022-08-18 13:27:23.124288','2022-08-17',1,5,'teacher01',0),(70,'기술가정 문제 -- 2','기술가정','기술가정 문제 더미','2022-08-18 13:27:53.921565','2022-08-18 13:29:21.855783','2022-08-17',1,5,'teacher01',0),(72,'과제 테스트','수학','테스트 테스트','2022-08-18 13:41:12.236278','2022-08-18 13:42:06.981242','1995-02-19',2,2,'ehddb2252',1),(73,'과제 테스트','수학','테스트 테스트','2022-08-18 13:41:15.807773','2022-08-18 13:41:59.767024','1995-02-19',2,2,'ehddb2252',1),(89,'데일리 과제 - 방정식 문제','수학','어떤 수와 20의 합은 어떤 수를 5배 한 것보다 4가 크다고 한다. 어떤 수를 구하여라.\r\n\r\n(이 문제의 정답을 제출 칸에 적어서 제출해주세요)','2022-08-18 16:29:21.350289','2022-08-18 16:30:04.383046','2022-08-15',1,5,'consultant_teach',0),(90,'데일리 과제 - 정수 계산 문제','수학','1 + (-1) + (-6) + 5 의 정답을 제출해주세요.','2022-08-18 16:30:55.451098','2022-08-18 16:31:18.096262','2022-08-16',1,5,'consultant_teach',0),(91,'데일리 과제  - 최대공약수','수학','45와 18의 최대공약수를 구해서 제출해주세요.','2022-08-18 16:32:18.627830','2022-08-18 16:32:18.627870','2022-08-17',1,5,'consultant_teach',0),(92,'데일리 과제 - 최소 공배수','수학','15와 20의 최소 공배수를 구해서 제출해주세요.','2022-08-18 16:33:06.661923','2022-08-18 16:33:06.661958','2022-08-18',1,5,'consultant_teach',0),(95,'등록합니다','과학','내용입니다','2022-08-18 18:47:35.648390','2022-08-18 19:01:03.046734','2022-08-23',1,7,'teacher01',0),(96,'기술 가정 문제 3','기술가정','기술 가정 문제 3번입니다.','2022-08-18 19:12:16.263749','2022-08-18 19:14:31.773520','2022-08-26',1,5,'teacher01',0),(97,'데일리 과제 - 정수 연산 문제 2','수학','6 - (-5)의 결과 값을 제출하세요.','2022-08-18 22:13:28.736513','2022-08-18 22:16:04.366731','2022-08-18',1,5,'consultant_teach',1);
/*!40000 ALTER TABLE `homework_teacherhomework` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-08-19 10:03:09
