-- MySQL dump 10.13  Distrib 8.0.28, for Win64 (x86_64)
--
-- Host: 3.36.69.192    Database: educolab
-- ------------------------------------------------------
-- Server version	8.0.30-0ubuntu0.20.04.2

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `survey_surveylist_target`
--

DROP TABLE IF EXISTS `survey_surveylist_target`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `survey_surveylist_target` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `surveylist_id` bigint NOT NULL,
  `userinfo_id` varchar(20) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `survey_surveylist_target_surveylist_id_userinfo_id_7192a8f9_uniq` (`surveylist_id`,`userinfo_id`),
  KEY `survey_surveylist_ta_userinfo_id_8e1a2a03_fk_accounts_` (`userinfo_id`),
  CONSTRAINT `survey_surveylist_ta_surveylist_id_3043991e_fk_survey_su` FOREIGN KEY (`surveylist_id`) REFERENCES `survey_surveylist` (`id`),
  CONSTRAINT `survey_surveylist_ta_userinfo_id_8e1a2a03_fk_accounts_` FOREIGN KEY (`userinfo_id`) REFERENCES `accounts_userinfo` (`username`)
) ENGINE=InnoDB AUTO_INCREMENT=656 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `survey_surveylist_target`
--

LOCK TABLES `survey_surveylist_target` WRITE;
/*!40000 ALTER TABLE `survey_surveylist_target` DISABLE KEYS */;
INSERT INTO `survey_surveylist_target` VALUES (89,66,'stu01'),(94,66,'stu02'),(88,66,'stu03'),(90,66,'stu05'),(91,66,'stu06'),(93,66,'stu07'),(92,66,'stu08'),(182,79,'Ejddb2252'),(177,79,'stu01'),(176,79,'stu02'),(183,79,'stu03'),(179,79,'stu05'),(180,79,'stu06'),(178,79,'stu07'),(181,79,'stu08'),(376,82,'coach_stu'),(375,82,'consultant_stu'),(202,82,'Ejddb2252'),(206,82,'stu01'),(203,82,'stu02'),(204,82,'stu03'),(205,82,'stu05'),(200,82,'stu06'),(207,82,'stu07'),(201,82,'stu08'),(378,83,'coach_stu'),(377,83,'consultant_stu'),(210,83,'Ejddb2252'),(394,83,'onefourone'),(393,83,'onefourtwo'),(391,83,'onethreeone'),(392,83,'onethreeth'),(395,83,'onethreetwo'),(214,83,'stu01'),(211,83,'stu02'),(212,83,'stu03'),(213,83,'stu05'),(208,83,'stu06'),(215,83,'stu07'),(209,83,'stu08'),(380,84,'coach_stu'),(379,84,'consultant_stu'),(218,84,'Ejddb2252'),(384,84,'onefourone'),(385,84,'onefourtwo'),(381,84,'onethreeone'),(382,84,'onethreeth'),(383,84,'onethreetwo'),(222,84,'stu01'),(219,84,'stu02'),(220,84,'stu03'),(221,84,'stu05'),(216,84,'stu06'),(223,84,'stu07'),(217,84,'stu08'),(246,89,'coach_stu'),(240,89,'consultant_stu'),(242,89,'Ejddb2252'),(247,89,'stu01'),(249,89,'stu02'),(248,89,'stu03'),(245,89,'stu05'),(241,89,'stu06'),(243,89,'stu07'),(244,89,'stu08'),(266,91,'coach_stu'),(260,91,'consultant_stu'),(262,91,'Ejddb2252'),(267,91,'stu01'),(269,91,'stu02'),(268,91,'stu03'),(265,91,'stu05'),(261,91,'stu06'),(263,91,'stu07'),(264,91,'stu08'),(279,92,'coach_stu'),(274,92,'consultant_stu'),(276,92,'Ejddb2252'),(272,92,'stu01'),(278,92,'stu02'),(270,92,'stu03'),(277,92,'stu05'),(271,92,'stu06'),(275,92,'stu07'),(273,92,'stu08'),(294,93,'coach_stu'),(284,93,'consultant_stu'),(291,93,'Ejddb2252'),(285,93,'onefourone'),(286,93,'onefourtwo'),(290,93,'onethreeone'),(287,93,'onethreeth'),(289,93,'onethreetwo'),(282,93,'stu01'),(293,93,'stu02'),(280,93,'stu03'),(292,93,'stu05'),(281,93,'stu06'),(288,93,'stu07'),(283,93,'stu08'),(309,94,'coach_stu'),(299,94,'consultant_stu'),(306,94,'Ejddb2252'),(300,94,'onefourone'),(301,94,'onefourtwo'),(305,94,'onethreeone'),(302,94,'onethreeth'),(304,94,'onethreetwo'),(297,94,'stu01'),(308,94,'stu02'),(295,94,'stu03'),(307,94,'stu05'),(296,94,'stu06'),(303,94,'stu07'),(298,94,'stu08'),(319,95,'coach_stu'),(314,95,'consultant_stu'),(316,95,'Ejddb2252'),(312,95,'stu01'),(318,95,'stu02'),(310,95,'stu03'),(317,95,'stu05'),(311,95,'stu06'),(315,95,'stu07'),(313,95,'stu08'),(339,101,'coach_stu'),(344,101,'consultant_stu'),(341,101,'Ejddb2252'),(343,101,'stu01'),(340,101,'stu02'),(338,101,'stu03'),(335,101,'stu05'),(337,101,'stu06'),(342,101,'stu07'),(336,101,'stu08'),(402,106,'coach_stu'),(406,106,'consultant_stu'),(408,106,'Ejddb2252'),(403,106,'stu01'),(401,106,'stu02'),(400,106,'stu03'),(404,106,'stu05'),(399,106,'stu06'),(405,106,'stu07'),(407,106,'stu08'),(418,110,'onethreeone'),(420,110,'onethreeth'),(419,110,'onethreetwo'),(572,134,'coach_stu'),(570,134,'consultant_stu'),(576,134,'Ejddb2252'),(581,134,'onefourone'),(569,134,'onefourtwo'),(578,134,'onethreeone'),(583,134,'onethreeth'),(582,134,'onethreetwo'),(574,134,'stu01'),(577,134,'stu02'),(579,134,'stu03'),(575,134,'stu05'),(580,134,'stu06'),(573,134,'stu07'),(571,134,'stu08'),(586,135,'coach_stu'),(584,135,'consultant_stu'),(590,135,'Ejddb2252'),(588,135,'stu01'),(591,135,'stu02'),(593,135,'stu03'),(589,135,'stu05'),(592,135,'stu06'),(587,135,'stu07'),(585,135,'stu08');
/*!40000 ALTER TABLE `survey_surveylist_target` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-08-19 10:03:13
