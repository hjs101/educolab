-- MySQL dump 10.13  Distrib 8.0.28, for Win64 (x86_64)
--
-- Host: 3.36.69.192    Database: educolab
-- ------------------------------------------------------
-- Server version	8.0.30-0ubuntu0.20.04.2

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `django_migrations`
--

DROP TABLE IF EXISTS `django_migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `django_migrations` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `app` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `applied` datetime(6) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=104 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `django_migrations`
--

LOCK TABLES `django_migrations` WRITE;
/*!40000 ALTER TABLE `django_migrations` DISABLE KEYS */;
INSERT INTO `django_migrations` VALUES (1,'contenttypes','0001_initial','2022-08-02 04:05:57.443987'),(2,'contenttypes','0002_remove_content_type_name','2022-08-02 04:05:57.600716'),(3,'auth','0001_initial','2022-08-02 04:05:58.172332'),(4,'auth','0002_alter_permission_name_max_length','2022-08-02 04:05:58.279101'),(5,'auth','0003_alter_user_email_max_length','2022-08-02 04:05:58.306533'),(6,'auth','0004_alter_user_username_opts','2022-08-02 04:05:58.336898'),(7,'auth','0005_alter_user_last_login_null','2022-08-02 04:05:58.364327'),(8,'auth','0006_require_contenttypes_0002','2022-08-02 04:05:58.387835'),(9,'auth','0007_alter_validators_add_error_messages','2022-08-02 04:05:58.417219'),(10,'auth','0008_alter_user_username_max_length','2022-08-02 04:05:58.446607'),(11,'auth','0009_alter_user_last_name_max_length','2022-08-02 04:05:58.473057'),(12,'auth','0010_alter_group_name_max_length','2022-08-02 04:05:58.528891'),(13,'auth','0011_update_proxy_permissions','2022-08-02 04:05:58.586684'),(14,'auth','0012_alter_user_first_name_max_length','2022-08-02 04:05:58.616070'),(15,'accounts','0001_initial','2022-08-02 04:05:59.633159'),(16,'account','0001_initial','2022-08-02 04:06:00.057310'),(17,'account','0002_email_max_length','2022-08-02 04:06:00.115104'),(18,'accounts','0002_alter_schoolinfo_name','2022-08-02 04:06:00.220896'),(19,'accounts','0003_alter_userinfo_grade','2022-08-02 04:06:00.340403'),(20,'accounts','0004_alter_userinfo_school','2022-08-02 04:06:00.615422'),(21,'admin','0001_initial','2022-08-02 04:06:00.969043'),(22,'admin','0002_logentry_remove_auto_add','2022-08-02 04:06:01.006268'),(23,'admin','0003_logentry_add_action_flag_choices','2022-08-02 04:06:01.041533'),(24,'authtoken','0001_initial','2022-08-02 04:06:01.263803'),(25,'authtoken','0002_auto_20160226_1747','2022-08-02 04:06:01.335867'),(26,'authtoken','0003_tokenproxy','2022-08-02 04:06:01.363296'),(30,'sessions','0001_initial','2022-08-02 04:06:02.183786'),(31,'sites','0001_initial','2022-08-02 04:06:02.272494'),(32,'sites','0002_alter_domain_unique','2022-08-02 04:06:02.329308'),(43,'notice','0001_initial','2022-08-03 07:25:33.032065'),(45,'accounts','0005_auto_20220805_0136','2022-08-04 16:36:52.215408'),(46,'survey','0001_initial','2022-08-04 16:41:25.616502'),(47,'survey','0002_auto_20220805_0136','2022-08-04 16:41:26.433526'),(48,'accounts','0006_pointlog_created_at','2022-08-04 16:44:54.782979'),(49,'survey','0003_remove_surveyquestionsanswer_survey_question_pk','2022-08-04 16:44:54.992144'),(50,'accounts','0007_pointlog_teacher','2022-08-05 01:55:18.127202'),(51,'accounts','0008_alter_userinfo_acc_point','2022-08-05 02:29:39.284161'),(52,'accounts','0005_alter_userinfo_school','2022-08-05 10:29:05.531622'),(53,'accounts','0009_merge_20220805_1928','2022-08-05 10:29:05.557089'),(54,'homework','0001_initial','2022-08-05 10:29:06.709053'),(55,'homework','0002_auto_20220802_1403','2022-08-05 10:29:06.951072'),(56,'homework','0003_auto_20220802_1428','2022-08-05 10:29:07.309863'),(57,'homework','0004_auto_20220802_1445','2022-08-05 10:29:08.237925'),(58,'homework','0005_auto_20220802_1531','2022-08-05 10:29:08.559219'),(59,'homework','0006_auto_20220802_1640','2022-08-05 10:29:08.782558'),(60,'homework','0007_alter_studenthomework_student','2022-08-05 10:29:08.848191'),(61,'homework','0008_auto_20220803_1340','2022-08-05 10:29:08.930471'),(62,'homework','0009_auto_20220803_1453','2022-08-05 10:29:09.296828'),(63,'homework','0010_auto_20220804_0938','2022-08-05 10:29:09.441803'),(64,'homework','0011_studenthomework_teacher','2022-08-05 10:29:09.601471'),(65,'notice','0002_alter_notice_views','2022-08-05 10:29:09.645515'),(66,'notice','0003_auto_20220803_1030','2022-08-05 10:30:55.103290'),(67,'accounts','0009_alter_userinfo_profil','2022-08-07 19:05:43.854424'),(68,'accounts','0010_alter_userinfo_profil','2022-08-07 19:12:30.845950'),(69,'accounts','0011_merge_20220808_1008','2022-08-08 01:08:22.225651'),(70,'mainpage','0001_initial','2022-08-08 01:08:22.691329'),(71,'mainpage','0002_rename_data_event_date','2022-08-08 01:08:22.754906'),(72,'accounts','0012_alter_userinfo_profil','2022-08-08 01:23:05.966322'),(73,'homework','0012_alter_submithomework_student','2022-08-08 01:23:06.019718'),(74,'accounts','0011_merge_20220808_1039','2022-08-08 01:40:06.448428'),(75,'survey','0002_alter_surveyquestionsanswer_question','2022-08-08 01:40:06.720457'),(77,'quiz','0001_initial','2022-08-08 06:56:23.560754'),(78,'accounts','0009_merge_20220808_0128','2022-08-09 05:06:19.416400'),(79,'accounts','0013_merge_20220809_1406','2022-08-09 05:06:19.441407'),(81,'pointshop','0001_initial','2022-08-09 15:17:49.807206'),(82,'accounts','0013_auto_20220809_2338','2022-08-09 15:17:50.258576'),(83,'pointshop','0002_rename_title_ptitle','2022-08-09 15:17:50.895491'),(84,'pointshop','0003_ptitle_content','2022-08-09 15:30:18.299403'),(85,'mainpage','0003_delete_timeline','2022-08-10 06:26:13.415693'),(86,'pointshop','0004_icon','2022-08-10 06:26:13.552496'),(87,'accounts','0014_userinfo_own_icon','2022-08-10 06:47:40.617600'),(88,'homework','0013_submithomework_check_flag','2022-08-10 07:45:17.119481'),(89,'accounts','0014_merge_20220811_1517','2022-08-11 06:18:30.886071'),(95,'accounts','0014_merge_20220812_1817','2022-08-12 09:17:55.721287'),(96,'accounts','0015_userinfo_wear_icon','2022-08-14 12:16:57.746509'),(97,'accounts','0016_merge_20220814_2305','2022-08-14 14:06:05.460120'),(98,'accounts','0017_auto_20220814_2305','2022-08-14 14:06:05.640356'),(99,'chat','0001_initial','2022-08-14 14:08:48.807099'),(100,'chat','0002_quizanswer_quizuser','2022-08-14 14:08:48.997136'),(101,'chat','0003_alter_quizuser_room','2022-08-14 14:08:49.056885'),(102,'accounts','0018_auto_20220816_0006','2022-08-15 15:07:20.901365'),(103,'accounts','0019_pointlog_school','2022-08-17 16:48:49.385591');
/*!40000 ALTER TABLE `django_migrations` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-08-19 10:03:11
